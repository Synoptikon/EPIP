from datetime import datetime,timezone,timedelta
import numpy as np
from epip.models import Event
from epip.catalog.completeness import CompletenessEngine
from epip.evaluation.scorecard import score_model
from epip.experiments.registry import ExperimentRegistry
from epip.forecast.state_rate import StateRateModel

def event(i,m=4.5):
    t=datetime(2025,1,1,tzinfo=timezone.utc)+timedelta(days=i)
    return Event(event_id=str(i),source='T',source_event_id=str(i),origin_time=t,latitude=20+i*0.01,longitude=-100,depth_km=10,magnitude=m,magnitude_type='Mw',catalog_version='t',raw_sha256=str(i),normalized_sha256=str(i))

def test_completeness_and_temporal():
    es=[event(i,4.0+(i%8)*.1) for i in range(40)]
    r=CompletenessEngine().estimate(es); assert r.n_events==40 and np.isfinite(r.mc)

def test_scorecard():
    s=score_model([.1,.9],[0,1]); assert s['brier']<.02 and s['n']==2

def test_state_rate():
    X=np.array([[0.],[1.],[2.],[3.],[4.]]); y=np.array([1,1,2,3,5.]); m=StateRateModel(); m.fit(X,y,l2=.1); assert len(m.params.coefficients)==1

def test_experiment_freeze(tmp_path):
    r=ExperimentRegistry(tmp_path/'x.sqlite'); eid=r.create(region_id='r',cutoff_time=datetime.now(timezone.utc),horizon_days=30,magnitude_min=5,magnitude_max=10,catalog_snapshot_id='s',config={'a':1}); r.freeze(eid); assert r.get(eid)[1]=='FROZEN'
