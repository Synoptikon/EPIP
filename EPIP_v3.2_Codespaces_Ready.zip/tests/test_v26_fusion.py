from epip.fusion import fuse_observable_state, ObservableStateStore


def test_fusion_preserves_missing_state_and_flags():
    s=fuse_observable_state(event_id='e1', tectonic={'association_confidence':0.8,'distance_to_fault_km':2.0}, input_snapshot_ids=['b','a'])
    assert s.features['distance_to_fault_km']==2.0
    assert 'GEODETIC_STATE_MISSING' in s.quality_flags
    assert 'STRESS_STATE_MISSING' in s.quality_flags
    assert s.input_snapshot_ids==['a','b']
    assert len(s.provenance_hash)==64


def test_fusion_state_store_roundtrip(tmp_path):
    db=tmp_path/'epip.sqlite'
    store=ObservableStateStore(db)
    s=fuse_observable_state(event_id='e2', geodetic={'strain_exx':1e-8,'strain_eyy':2e-8,'quality':'good','uncertainty':1e-9})
    store.save(s)
    assert store.get(s.state_id)['state_id']==s.state_id
    assert store.latest()['event_id']=='e2'


def test_fusion_does_not_call_unvalidated_stress_physical():
    s=fuse_observable_state(stress={'delta_cfs_pa':123.0,'validated':False,'uncertainty_pa':20.0})
    assert s.features['delta_cfs_pa']==123.0
    assert 'STRESS_NOT_VALIDATED' in s.quality_flags
