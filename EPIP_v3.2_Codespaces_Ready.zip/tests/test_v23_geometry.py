from epip.tectonics.geometry import GeometryStore
from epip.tectonics.association import TectonicGeometryEngine
from epip.tectonics.state import build_tectonic_state

def stores():
    plates=GeometryStore.from_features([
        {'id':'PAC','geometry':{'type':'Polygon','coordinates':[[[-5,-5],[5,-5],[5,5],[-5,5],[-5,-5]]]},'properties':{'boundary_type':'transform','source':'fixture'}}
    ],dataset='plates',version='2026.1')
    faults=GeometryStore.from_features([
        {'id':'F001','geometry':{'type':'LineString','coordinates':[[0,-10],[0,10]]},'properties':{'fault_type':'strike-slip','slip_rate_mm_yr':12,'strike':0,'source':'fixture'}}
    ],dataset='faults',version='2026.1')
    return plates,faults

def test_geometry_validation_and_association():
    p,f=stores(); assert p.validate()['valid'] and f.validate()['valid']
    a=TectonicGeometryEngine(p,f).associate(event_id='e1',latitude=.1,longitude=.1,depth_km=8)
    assert a.plate_id=='PAC' and a.fault_id=='F001' and 0<a.association_confidence<=1
    assert a.distance_to_fault_km < 20

def test_state_contains_observable_tectonic_fields():
    p,f=stores(); a=TectonicGeometryEngine(p,f).associate(event_id='e1',latitude=.1,longitude=.1)
    s=build_tectonic_state('e1',a)
    assert s.fault_type=='strike-slip' and s.slip_rate_mm_yr==12
    assert s.geometry_version=='2026.1|2026.1'
