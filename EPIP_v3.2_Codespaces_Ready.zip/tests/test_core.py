from datetime import datetime, timezone, timedelta
import numpy as np
import pytest
from epip.forecast import PoissonBaseline, validate_forecast, freeze_forecast
from epip.evaluation import brier_score, log_loss
from epip.core.validation import require_temporal_cutoff

def test_poisson_probability():
    now=datetime.now(timezone.utc); end=now+timedelta(days=30)
    f=PoissonBaseline().forecast(cutoff_time=now,horizon_end=end,region_id='test',
        cells=[{'longitude':0,'latitude':0,'depth_km':10}],input_snapshot_ids=['s1'],
        rate_per_cell=np.array([0.5]),magnitude_min=5,magnitude_max=6)
    assert 0 < f.cells[0].probability < 1
    assert abs(f.cells[0].probability-(1-np.exp(-.5)))<1e-12

def test_freeze_contract():
    now=datetime.now(timezone.utc); end=now+timedelta(days=1)
    f=PoissonBaseline().forecast(cutoff_time=now,horizon_end=end,region_id='test',
        cells=[{'longitude':0,'latitude':0,'depth_km':10}],input_snapshot_ids=['s1'],
        rate_per_cell=np.array([0.1]),magnitude_min=5,magnitude_max=6)
    f=validate_forecast(f); assert f.status=='VALIDATED'
    f=freeze_forecast(f); assert f.status=='FROZEN'

def test_temporal_leakage():
    cutoff=datetime(2026,1,1,tzinfo=timezone.utc)
    with pytest.raises(ValueError): require_temporal_cutoff(datetime(2026,1,2,tzinfo=timezone.utc),cutoff)

def test_metrics():
    assert brier_score([.9,.1],[1,0])<.02
    assert log_loss([.9,.1],[1,0])<.11
