from datetime import datetime, timedelta, timezone
import numpy as np
from epip.catalog.master import MasterCatalog
from epip.catalog.store import CatalogStore
from epip.forecast.etas import ETASModel, ETASParameters
from epip.ingest.normalize import normalize_event
from epip.evaluation.prospective import ProspectiveEvaluator
from epip.models import Event

def ev(i,t,m=4.0,lat=20,lon=-100):
    return normalize_event('TEST',str(i),origin_time=t,latitude=lat+i*0.01,longitude=lon+i*0.01,depth_km=10,magnitude=m,magnitude_type='Mw',catalog_version='test',raw_payload={'i':i})

def test_catalog_reconciles_latest():
    t=datetime(2026,1,1,tzinfo=timezone.utc); c=MasterCatalog([ev(1,t),ev(2,t+timedelta(seconds=1))]); assert len(c.events)==2

def test_store_snapshot(tmp_path):
    db=tmp_path/'x.sqlite'; s=CatalogStore(db); t=datetime(2026,1,1,tzinfo=timezone.utc); events=[ev(1,t)]
    assert s.upsert(events)==1; snap=s.create_snapshot('TEST','1',{},events); assert snap.record_count==1

def test_etas_fit_and_forecast():
    t=datetime(2026,1,1,tzinfo=timezone.utc); events=[ev(i,t+timedelta(days=i),4.5+0.05*i) for i in range(12)]
    model=ETASModel(); params,_=model.fit(events,region_area_km2=10000,m0=4.0)
    assert params.p>1 and params.q>1 and params.mu>0
    cells=[{'longitude':-100,'latitude':20,'depth_km':10}]
    f=model.forecast_grid(events=events,cutoff_time=t+timedelta(days=11),horizon_end=t+timedelta(days=12),cells=cells,cell_area_km2=100,region_area_km2=10000,magnitude_min=4,magnitude_max=8,input_snapshot_ids=['s'])
    assert 0<=f.cells[0].probability<=1

def test_metrics():
    e=ProspectiveEvaluator(); r=e.evaluate_binary('x',[0.1,0.9],[0,1],datetime.now(timezone.utc)); assert r['brier']<0.02
