import numpy as np
import pytest
from epip.stress import ElasticMedium, RectangularRupture, ReceiverFaultPlane, stress_to_cfs, slip_from_mw


def test_moment_slip_relation():
    slip = slip_from_mw(6.5, 20_000, 10_000, 30e9)
    assert slip > 0
    rupture = RectangularRupture('r1','test',0,0,5000,20_000,10_000,90,30,0,slip,ElasticMedium())
    assert rupture.moment_nm == pytest.approx(10**(1.5*6.5+9.1), rel=1e-12)


def test_cfs_zero_tensor():
    receiver=ReceiverFaultPlane('rx',0,0,5000,90,45,0)
    r=stress_to_cfs(np.zeros((3,3)), receiver)
    assert r.delta_cfs_pa == 0


def test_cfs_shear_sign():
    receiver=ReceiverFaultPlane('rx',0,0,5000,0,45,0,friction=0.6)
    sigma=np.zeros((3,3)); sigma[0,2]=sigma[2,0]=10e6
    r=stress_to_cfs(sigma, receiver)
    assert np.isfinite(r.delta_cfs_pa)


def test_engine_rejects_unvalidated_backend():
    class Fake:
        validated=False
    from epip.stress.engine import FiniteFaultStressEngine
    with pytest.raises(ValueError): FiniteFaultStressEngine(Fake())
