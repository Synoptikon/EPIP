from datetime import datetime, timedelta, timezone
from epip.geodesy.state import estimate_station_velocity, fit_velocity_strain
from epip.geodesy.insar import normalize_insar, summarize_insar
from epip.geodesy.store import GeodeticStore


def test_velocity_uncertainty_and_strain(tmp_path):
    t0=datetime(2020,1,1,tzinfo=timezone.utc); obs=[]
    for i,(lat,lon) in enumerate([(0,0),(0,.1),(.1,0),(.1,.1),(.2,0),(.2,.1)]):
        for j in range(8):
            obs.append({'station_id':str(i),'timestamp':t0+timedelta(days=365.25*j),'latitude':lat,'longitude':lon,'east_mm':2*j,'north_mm':j,'up_mm':0.2*j})
    v=estimate_station_velocity(obs)
    assert len(v)==6 and all(abs(x['east_mm_yr']-2)<1e-8 for x in v)
    assert all(x['east_sigma_mm_yr'] is not None for x in v)
    s=fit_velocity_strain(v,snapshot_id='g24')
    assert s.quality in {'good','usable'} and s.strain_exx is not None and s.n_dof>0


def test_insar_and_store(tmp_path):
    rows=normalize_insar([{'latitude':20,'longitude':-100,'deformation_mm':3.2,'sigma_mm':0.8,'track':'T1'}])
    assert rows[0]['quality']=='good'
    assert summarize_insar(rows)['count']==1
    store=GeodeticStore(tmp_path/'epip.sqlite')
    meta=store.save_snapshot('s1','test','1','2026-08-24T00:00:00Z','insar',rows,'good')
    assert meta['record_count']==1 and len(meta['sha256'])==64
