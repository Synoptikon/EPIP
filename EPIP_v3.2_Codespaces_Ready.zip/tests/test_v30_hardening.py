from datetime import datetime, timezone, timedelta
import json
from epip.tectonics.geometry import GeometryStore
from epip.forecast.ensemble import ProbabilisticEnsemble, EnsembleWeights, weights_from_scores
from epip.forecast.etas import ETASModel
from epip.models import Event


def test_geojson_semantic_id_from_properties(tmp_path):
    p=tmp_path/'faults.geojson'
    p.write_text(json.dumps({'type':'FeatureCollection','features':[{'type':'Feature','geometry':{'type':'LineString','coordinates':[[0,0],[1,1]]},'properties':{'fault_id':'F-REAL'}}]}))
    s=GeometryStore.from_geojson(p,dataset='faults',version='1',id_field='fault_id')
    assert s.features[0].feature_id=='F-REAL'


def test_ensemble_alignment_and_weights():
    now=datetime.now(timezone.utc)
    base={'forecast_id':'a','model_id':'x','model_version':'1','created_at':now,'cutoff_time':now,'horizon_end':now+timedelta(days=1),'region_id':'r','magnitude_min':5,'magnitude_max':7,'input_snapshot_ids':[],'code_version':'3','parameter_hash':'x','status':'CREATED'}
    from epip.models import Forecast, ForecastCell
    a=Forecast(**base,cells=[ForecastCell(longitude=1,latitude=2,depth_km=5,magnitude_min=5,magnitude_max=7,probability=.2,expected_count=.2,uncertainty=.4)])
    b=a.model_copy(deep=True); b.forecast_id='b'; b.cells=[ForecastCell(longitude=1,latitude=2,depth_km=5,magnitude_min=5,magnitude_max=7,probability=.6,expected_count=.6,uncertainty=.7)]
    out=ProbabilisticEnsemble(EnsembleWeights(.25,.75)).combine(a,b)
    assert abs(out.cells[0].probability-.5)<1e-12
    w=weights_from_scores(.1,.2); assert w.poisson>w.etas


def _event(i, day):
    t=datetime(2026,1,1,tzinfo=timezone.utc)+timedelta(days=day)
    return Event(event_id=f'E{i}',source='T',source_event_id=str(i),origin_time=t,latitude=.01*i,longitude=.01*i,depth_km=8,magnitude=4.5+(i%4)*.1,catalog_version='test',raw_sha256='0'*64,normalized_sha256='1'*64)


def test_etas_parameters_are_nonnegative_and_subcritical():
    events=[_event(i,i*.25) for i in range(24)]
    m=ETASModel(); params,_=m.fit(events,region_area_km2=50000,m0=4.0)
    assert params.alpha>=0
    assert params.p>1 and params.q>1
    assert params.branching_ratio<.95
