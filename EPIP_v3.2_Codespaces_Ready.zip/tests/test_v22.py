from datetime import datetime, timedelta, timezone
from epip.catalog.global_catalog import GlobalMasterCatalog
from epip.catalog.homogenize import MagnitudeCompleteness, MagnitudeHomogenizer, MagnitudeRule
from epip.catalog.decluster import WindowDeclusterer
from epip.experiments.prospective import ExperimentSpec, ProspectiveExperiment
from epip.forecast.baselines import poisson_probability
from epip.ingest.normalize import normalize_event

def ev(i,t,m=4.0,lat=20,lon=-100,src='TEST'):
    return normalize_event(src,str(i),origin_time=t,latitude=lat,longitude=lon,depth_km=10,magnitude=m,magnitude_type='Mw',catalog_version='test',raw_payload={'i':i})

def test_global_reconciliation_cross_source():
    t=datetime(2026,1,1,tzinfo=timezone.utc)
    a=ev(1,t,5.0); b=ev(99,t+timedelta(seconds=3),5.1,src='OTHER')
    cat=GlobalMasterCatalog(); out,q,aliases=cat.build([a,b])
    assert len(out)==1 and len(aliases)==1 and q.duplicate_count==1

def test_magnitude_rule_and_mc():
    h=MagnitudeHomogenizer({'ML':MagnitudeRule('ML',0.5,0.9)})
    mw,sigma,method=h.convert(4.0,'ML'); assert mw==4.1 and sigma>0 and method.startswith('rule')
    mags=[3.0+(i%30)*0.1 for i in range(100)] + [4.0]*100
    assert MagnitudeCompleteness().estimate(mags)>=3.0

def test_declustering():
    t=datetime(2026,1,1,tzinfo=timezone.utc)
    a=ev(1,t,6); b=ev(2,t+timedelta(hours=1),4.2,lat=20.01,lon=-99.99)
    r=WindowDeclusterer(time_days=2,distance_km=50,magnitude_scale=0).run([a,b])
    assert len(r.clustered)==1 and r.parent[b.event_id]==a.event_id

def test_experiment_freeze(tmp_path):
    db=tmp_path/'e.sqlite'; x=ProspectiveExperiment(db)
    t=datetime(2026,1,1,tzinfo=timezone.utc)
    spec=ExperimentSpec('x','poisson','1','test',t,t+timedelta(days=7),5,9,'snap','code')
    eid=x.create(spec); x.freeze(eid); row=x.get(eid); assert row[1]=='FROZEN' and row[2]

def test_poisson_baseline():
    t=datetime(2026,1,1,tzinfo=timezone.utc)
    events=[ev(i,t+timedelta(days=i),5) for i in range(10)]
    p=poisson_probability(events,1000,10,100,5)
    assert 0<p<1
