from datetime import datetime, timedelta, timezone
from epip.geodesy.state import estimate_station_velocity, fit_velocity_strain

def test_velocity_and_strain():
    t0=datetime(2020,1,1,tzinfo=timezone.utc); obs=[]
    for i,(lat,lon) in enumerate([(0,0),(0,.1),(.1,0),(.1,.1)]):
        for j in range(5):
            obs.append({'station_id':str(i),'timestamp':t0+timedelta(days=365.25*j),'latitude':lat,'longitude':lon,'east_mm':2*j,'north_mm':j,'up_mm':0})
    v=estimate_station_velocity(obs)
    assert len(v)==4 and all(x['east_mm_yr'] is not None for x in v)
    s=fit_velocity_strain(v,snapshot_id='g1')
    assert s.station_count==4 and s.strain_exx is not None and s.principal_strain_max is not None
