# EPIP v3.2 — GitHub Codespaces

## Crear el Codespace

En GitHub: **Code → Codespaces → Create codespace on main**.

El `.devcontainer/devcontainer.json` instala Python y las dependencias automáticamente.

## Probar conectividad USGS

```bash
epip-usgs-test
```

Debe mostrar DNS OK y HTTPS OK.

## Validar EPIP

```bash
make test
```

## Primer experimento real

```bash
./scripts/epip-live   --region mexico   --days 365   --forecast-days 30   --min-mag 3.0   --magnitude 4.5
```

El comando no utiliza fallback sintético. Si USGS no está disponible, termina con error.

## Reproducibilidad

El pipeline debe conservar snapshots, provenance, configuración y forecast registry.
Los forecasts congelados no deben modificarse después de su creación.
