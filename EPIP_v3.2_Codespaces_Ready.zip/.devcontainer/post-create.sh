#!/usr/bin/env bash
set -euo pipefail
python -m pip install --upgrade pip
[ -f requirements.txt ] && pip install -r requirements.txt
[ -f pyproject.toml ] && pip install -e .
mkdir -p data/raw data/snapshots data/forecasts reports
echo "EPIP v3.2 Codespace ready."
echo "Run: epip-usgs-test"
echo "Run: epip-live --region mexico --days 365 --forecast-days 30 --min-mag 3.0 --magnitude 4.5"
