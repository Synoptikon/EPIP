# EPIP v3.2 Final Release — Validation Report

Date: 2026-08-24

## Software validation

- Python compilation: PASS
- Unit/integration tests: **32 passed**
- Offline end-to-end fusion demo: PASS
- Release validator: PASS
- Package layout: flat installable project root

## Live-data validation

The live USGS/ComCat execution path was exercised. The current sandbox cannot resolve external DNS, so the request failed after the configured retry policy. EPIP terminated with a non-zero status and **did not substitute synthetic data**.

Observed failure:

`USGS request failed after 5 attempts: [Errno -3] Temporary failure in name resolution`

This is an environment/network limitation, not a fabricated forecast result.

## Scientific safeguards

- USGS FDSN pagination at the documented 20,000-record limit.
- Retry/backoff and explicit network failure.
- SHA-256 source/normalized event provenance.
- Frozen experiment and forecast registry.
- No post-cutoff observations in prospective forecasts.
- Constrained/subcritical ETAS.
- Explicit completeness estimate and uncertainty.
- Physical ΔCFS gated behind the physical solver.
- No silent synthetic fallback.

## Scientific status

EPIP v3.2 is **software-ready and experiment-ready**. It is not scientifically established that EPIP outperforms Poisson or ETAS until the frozen prospective experiment is run against real observations over the predefined horizons and evaluated with the scorecard.
