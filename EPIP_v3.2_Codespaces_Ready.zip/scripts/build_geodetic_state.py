from __future__ import annotations
import argparse
from datetime import datetime, timezone
from epip.geodesy.ingest import load_gnss_observations, load_insar_observations
from epip.geodesy.state import estimate_station_velocity, fit_velocity_strain
from epip.geodesy.store import GeodeticStore

def main():
    ap=argparse.ArgumentParser(description='Build an EPIP v2.4 geodetic state snapshot')
    ap.add_argument('--gnss', required=True)
    ap.add_argument('--snapshot-id', required=True)
    ap.add_argument('--source', default='gnss')
    ap.add_argument('--version', default='unknown')
    ap.add_argument('--db', default='data/epip.sqlite')
    ap.add_argument('--insar')
    args=ap.parse_args()
    obs=load_gnss_observations(args.gnss)
    stations=estimate_station_velocity(obs)
    state=fit_velocity_strain(stations,snapshot_id=args.snapshot_id)
    store=GeodeticStore(args.db)
    store.save_snapshot(args.snapshot_id,args.source,args.version,datetime.now(timezone.utc).isoformat(),'gnss',obs,state.quality,{'product':'velocity+strain'})
    store.save_station_velocities(args.snapshot_id,stations); store.save_state(state)
    if args.insar:
        insar=load_insar_observations(args.insar)
        store.save_snapshot(args.snapshot_id+':insar', 'insar', args.version, datetime.now(timezone.utc).isoformat(),'insar',insar,'validated',{'product':'deformation'})
    print(state.to_dict())

if __name__=='__main__': main()
