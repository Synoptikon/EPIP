"""Smoke-test the optional physical stress backend.

This script never falls back to a proxy. If cutde is absent it reports that the
physical backend is unavailable.
"""
from epip.stress import ElasticMedium, RectangularRupture, ReceiverFaultPlane, FiniteFaultStressEngine, slip_from_mw
from epip.stress.backend import CutdeHalfspaceBackend

r = RectangularRupture(
    'benchmark-rupture','synthetic',0,0,5000,20_000,10_000,90,30,0,
    slip_from_mw(6.5,20_000,10_000,30e9),ElasticMedium())
rx = ReceiverFaultPlane('receiver',30_000,10_000,5_000,90,45,0)
engine = FiniteFaultStressEngine(CutdeHalfspaceBackend())
print(engine.compute(r,rx))
