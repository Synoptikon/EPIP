#!/usr/bin/env python3
import argparse, json, shutil
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from epip.tectonics.geometry import GeometryStore

p=argparse.ArgumentParser(description='Validate and import a versioned EPIP GeoJSON geometry dataset')
p.add_argument('--input',required=True); p.add_argument('--dataset',required=True); p.add_argument('--version',required=True); p.add_argument('--output-dir',default='data/geometry')
p.add_argument('--id-field')
a=p.parse_args(); store=GeometryStore.from_geojson(a.input,dataset=a.dataset,version=a.version,id_field=a.id_field,source_uri=str(Path(a.input).resolve()))
check=store.validate()
if not check['valid']:
    print(json.dumps(check,indent=2)); raise SystemExit(2)
out=Path(a.output_dir); out.mkdir(parents=True,exist_ok=True); target=out/f'{a.dataset}__{a.version}.geojson'; shutil.copy2(a.input,target)
(target.with_suffix('.manifest.json')).write_text(json.dumps(store.manifest(),indent=2),encoding='utf-8')
print(json.dumps({**check,'target':str(target),'manifest':store.manifest()},indent=2))
