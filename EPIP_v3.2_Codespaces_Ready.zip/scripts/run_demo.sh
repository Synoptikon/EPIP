#!/usr/bin/env bash
set -euo pipefail
python -m pip install -e .
pytest -q
python scripts/demo_end_to_end.py
