"""Offline deterministic EPIP smoke test. No external data are required."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from datetime import datetime, timezone, timedelta
from epip.tectonics.geometry import GeometryStore
from epip.tectonics.association import TectonicGeometryEngine
from epip.tectonics.state import build_tectonic_state
from epip.fusion.state import fuse_observable_state
from epip.forecast.ensemble import ProbabilisticEnsemble, EnsembleWeights
from epip.models import Forecast, ForecastCell


def main():
    plates=GeometryStore.from_features([{'id':'PLATE-A','geometry':{'type':'Polygon','coordinates':[[[-2,-2],[2,-2],[2,2],[-2,2],[-2,-2]]]},'properties':{'boundary_type':'transform'}}],dataset='demo-plates',version='demo-1')
    faults=GeometryStore.from_features([{'id':'FAULT-1','geometry':{'type':'LineString','coordinates':[[0,-3],[0,3]]},'properties':{'fault_type':'strike-slip','slip_rate_mm_yr':15,'strike':0}}],dataset='demo-faults',version='demo-1')
    assoc=TectonicGeometryEngine(plates,faults).associate(event_id='demo-event',latitude=.1,longitude=.1,depth_km=8)
    tectonic=build_tectonic_state('demo-event',assoc).to_dict()
    state=fuse_observable_state(event_id='demo-event',tectonic=tectonic,geodetic={'strain_exx':1e-9,'strain_eyy':-2e-9,'strain_exy':5e-10,'principal_strain_max':1.1e-9,'principal_strain_min':-2.1e-9,'max_shear_strain':1.6e-9,'rotation_rad_yr':2e-10,'quality':'good','uncertainty':2e-10},stress={'delta_cfs_pa':12000,'uncertainty_pa':3000,'validated':False},input_snapshot_ids=['demo-geometry','demo-geodesy'])
    now=datetime.now(timezone.utc); end=now+timedelta(days=30)
    cell=ForecastCell(longitude=.1,latitude=.1,depth_km=8,magnitude_min=5,magnitude_max=7,probability=.2,expected_count=.22,uncertainty=.47)
    base=dict(forecast_id='p',model_id='poisson',model_version='1',created_at=now,cutoff_time=now,horizon_end=end,region_id='demo',magnitude_min=5,magnitude_max=7,input_snapshot_ids=['demo-catalog'],code_version='3.0.0',parameter_hash='p',status='CREATED',cells=[cell])
    poisson=Forecast(**base)
    cell2=cell.model_copy(update={'probability':.3,'expected_count':.36,'uncertainty':.6})
    etas=poisson.model_copy(deep=True); etas.forecast_id='e'; etas.model_id='etas'; etas.cells=[cell2]
    ens=ProbabilisticEnsemble(EnsembleWeights(.4,.6)).combine(poisson,etas)
    print({'state_id':state.state_id,'quality_score':state.quality_score,'ensemble_probability':ens.cells[0].probability})

if __name__=='__main__': main()
