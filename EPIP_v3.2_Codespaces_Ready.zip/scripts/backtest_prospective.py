#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime,timedelta,timezone
import argparse,json,sys
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from epip.catalog.store import CatalogStore
from epip.experiments.scientific import ScientificPipeline,Region
from epip.experiments.registry import ExperimentRegistry

def parse(s): return datetime.fromisoformat(s.replace('Z','+00:00'))
def main():
 p=argparse.ArgumentParser();p.add_argument('--db',default='data/epip.sqlite');p.add_argument('--region',default='mexico');p.add_argument('--start',required=True);p.add_argument('--end',required=True);p.add_argument('--step-days',type=int,default=30);p.add_argument('--horizon-days',type=int,default=30);p.add_argument('--magnitude',type=float,default=4.5);p.add_argument('--report',default='artifacts/prospective_backtest.md');a=p.parse_args()
 regions={'mexico':Region('mexico',14,33,-119,-86,1964375.0),'global':Region('global',-90,90,-180,180,510072000.0)};r=regions[a.region];store=CatalogStore(a.db);events=store.query(start=parse(a.start),end=parse(a.end));pipe=ScientificPipeline(a.db); rows=[]
 cutoff=parse(a.start)
 while cutoff+timedelta(days=a.horizon_days)<=parse(a.end):
  hist=[e for e in events if e.origin_time<=cutoff]; obs=[e for e in events if cutoff<e.origin_time<=cutoff+timedelta(days=a.horizon_days) and e.magnitude>=a.magnitude]
  snap=store.create_snapshot('EPIP_BACKTEST', '3.1.0', {'cutoff':cutoff.isoformat(),'horizon_days':a.horizon_days,'region':r.__dict__},hist)
  eid=pipe.registry.create(region_id=r.region_id,cutoff_time=cutoff,horizon_days=a.horizon_days,magnitude_min=a.magnitude,magnitude_max=10,catalog_snapshot_id=snap.snapshot_id,code_version='epip-3.1.0',config={'grid_n':8});pipe.registry.freeze(eid)
  fs=pipe.build_forecasts(hist,cutoff,a.horizon_days,r,a.magnitude,10,snapshot_ids=[snap.snapshot_id]); scores=pipe.evaluate_against_events(fs,obs); rows.append({'experiment_id':eid,'cutoff':cutoff.isoformat(),'observation_count':len(obs),'scores':scores}); cutoff+=timedelta(days=a.step_days)
 out={'region':r.__dict__,'start':a.start,'end':a.end,'horizon_days':a.horizon_days,'magnitude_min':a.magnitude,'windows':rows};Path(a.report).parent.mkdir(parents=True,exist_ok=True);Path(a.report).write_text('# EPIP Prospective Backtest\n\n```json\n'+json.dumps(out,indent=2,default=str)+'\n```\n',encoding='utf-8');Path(str(a.report).replace('.md','.json')).write_text(json.dumps(out,indent=2,default=str),encoding='utf-8');print(json.dumps({'windows':len(rows),'report':a.report},indent=2))
if __name__=='__main__':main()
