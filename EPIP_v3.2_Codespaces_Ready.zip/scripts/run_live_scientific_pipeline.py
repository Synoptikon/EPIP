#!/usr/bin/env python3
from datetime import datetime,timedelta,timezone
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import argparse,json
from epip.experiments.scientific import ScientificPipeline,Region
from urllib.error import URLError

def main():
    p=argparse.ArgumentParser(); p.add_argument('--region',default='mexico'); p.add_argument('--days',type=int,default=365); p.add_argument('--forecast-days',type=int,default=30); p.add_argument('--min-mag',type=float,default=2.5); p.add_argument('--magnitude',type=float,default=4.5); p.add_argument('--db',default='data/epip.sqlite'); p.add_argument('--report',default='artifacts/live_pipeline.md'); a=p.parse_args()
    regions={'mexico':Region('mexico',14,33,-119,-86,1964375.0),'global':Region('global',-90,90,-180,180,510072000.0)}; r=regions[a.region]
    end=datetime.now(timezone.utc); start=end-timedelta(days=a.days); pipe=ScientificPipeline(a.db)
    try:
        events,snap,inserted=pipe.acquire_usgs(start,end,r,a.min_mag)
    except (URLError, RuntimeError, OSError) as exc:
        raise SystemExit(f'EPIP live ingestion failed: {exc}. No synthetic fallback is permitted.')
    eid=pipe.registry.create(region_id=r.region_id,cutoff_time=end,horizon_days=a.forecast_days,magnitude_min=a.magnitude,magnitude_max=10,catalog_snapshot_id=snap.snapshot_id,code_version='epip-3.2.0',config={'grid_n':8,'min_catalog_magnitude':a.min_mag}); pipe.registry.freeze(eid)
    forecasts=pipe.build_forecasts(events,end,a.forecast_days,r,a.magnitude,10,snapshot_ids=[snap.snapshot_id]); pipe.save_forecasts(forecasts)
    Path(a.report).parent.mkdir(parents=True,exist_ok=True); exp={'region_id':r.region_id,'cutoff_time':end.isoformat(),'horizon_days':a.forecast_days,'magnitude_min':a.magnitude,'magnitude_max':10,'catalog_snapshot_id':snap.snapshot_id,'events':len(events),'inserted':inserted}
    pipe.write_report(a.report,exp,{},notes=['Live forecast frozen; evaluate only after horizon_end.','ETAS is omitted if calibration fails or catalog is insufficient.'])
    print(json.dumps({'experiment_id':eid,'snapshot_id':snap.snapshot_id,'events':len(events),'inserted':inserted,'forecasts':{k:(v.forecast_id if v else None) for k,v in forecasts.items()},'report':a.report},indent=2))
if __name__=='__main__': main()
