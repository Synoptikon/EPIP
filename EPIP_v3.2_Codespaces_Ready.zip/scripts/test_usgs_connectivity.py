#!/usr/bin/env python3
import socket, ssl, urllib.request

HOST = "earthquake.usgs.gov"
URL = "https://earthquake.usgs.gov/fdsnws/event/1/version"

print(f"Testing DNS: {HOST}")
ip = socket.gethostbyname(HOST)
print(f"DNS OK: {ip}")

print(f"Testing HTTPS: {URL}")
ctx = ssl.create_default_context()
req = urllib.request.Request(URL, headers={"User-Agent": "EPIP/3.2"})
with urllib.request.urlopen(req, timeout=15, context=ctx) as r:
    print(f"HTTPS OK: HTTP {r.status}")
    print(f"USGS FDSN version: {r.read().decode().strip()}")
