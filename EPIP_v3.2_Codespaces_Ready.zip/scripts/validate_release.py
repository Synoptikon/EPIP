
#!/usr/bin/env python3
from pathlib import Path
import subprocess,sys,py_compile
root=Path(__file__).resolve().parent.parent
files=list(root.glob('epip/**/*.py'))+list(root.glob('scripts/*.py'))
for f in files: py_compile.compile(str(f),doraise=True)
cmd=[sys.executable,'-m','pytest','-q']
r=subprocess.run(cmd,cwd=root)
if r.returncode: raise SystemExit(r.returncode)
print('EPIP v3.2 release validation: PASS')
