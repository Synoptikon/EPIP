# EPIP Roadmap — v3.1

## EPIP v3.1 — Global Scientific Validation Foundation

The production architecture is now frozen around a reproducible scientific loop:

`real data -> versioned snapshot -> completeness -> state -> frozen forecast -> observation -> evaluation -> skill`

### Implemented
- USGS/ComCat live acquisition adapter with provenance.
- Master catalog and versioned snapshots.
- Temporal completeness engine with bootstrap uncertainty.
- Real tectonic geometry, GNSS/InSAR and finite-fault stress interfaces from v3.0.
- Immutable scientific experiment registry.
- 24h/7d/30d/90d horizon-ready forecast contracts.
- Poisson and hardened ETAS baselines.
- Probabilistic ensemble.
- State-rate Poisson challenger for frozen feature matrices.
- Prospective backtest runner.
- Brier, LogLoss, Poisson likelihood and calibration scorecard.
- Reproducible Markdown/JSON reports.
- API endpoints for experiments and completeness.

### Scientific governance
1. No model is promoted from retrospective performance alone.
2. Forecast inputs are frozen at the cutoff.
3. Every result records snapshot IDs and code/config hashes.
4. Missing tectonic/geodetic/stress state is never silently replaced by zero.
5. ETAS fits must remain subcritical and bounded.
6. Physical ΔCFS requires a validated elastic backend; proxies are not labelled ΔCFS.

### v3.2 target
- Operational global source adapters beyond USGS/ComCat.
- Automated GNSS/InSAR snapshot acquisition where stable public APIs are available.
- Validated regional fault-slip/finite-fault benchmark suite.
- Rolling global prospective experiments.
- Bootstrap confidence intervals and model comparison reports.
- Champion/challenger promotion based only on prospective skill.

### v4.0 target
A continuously operating Earthquake Probabilistic Intelligence Platform with global live data, immutable forecast registry, automated evaluation and externally auditable model governance.
