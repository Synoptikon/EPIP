from __future__ import annotations
from dataclasses import dataclass
from collections import defaultdict
from datetime import timedelta
from epip.models import Event
from epip.geometry.association import haversine_km
from .homogenize import MagnitudeHomogenizer, MagnitudeCompleteness

@dataclass(frozen=True)
class CatalogQC:
    input_count:int; output_count:int; duplicate_count:int; completeness_magnitude:float|None; quality_flags:dict[str,int]

class GlobalMasterCatalog:
    """Cross-source reconciliation with auditable duplicate links and homogeneous magnitudes."""
    def __init__(self, homogenizer: MagnitudeHomogenizer|None=None):
        self.homogenizer=homogenizer or MagnitudeHomogenizer()
    def reconcile(self, events:list[Event], time_seconds=20, distance_km=15, magnitude_delta=0.35):
        ordered=sorted(events,key=lambda e:(e.origin_time,e.source_event_id)); canonical=[]; aliases={}
        for e in ordered:
            dup=None
            for c in reversed(canonical[-100:]):
                dt=abs((e.origin_time-c.origin_time).total_seconds())
                if dt>time_seconds: break
                if abs(e.magnitude-c.magnitude)<=magnitude_delta and haversine_km(e.latitude,e.longitude,c.latitude,c.longitude)<=distance_km:
                    dup=c; break
            if dup:
                aliases[e.event_id]=dup.event_id
            else: canonical.append(e)
        return canonical, aliases
    def build(self, events:list[Event]):
        canonical,aliases=self.reconcile(events)
        transformed=self.homogenizer.transform(canonical)
        mc= MagnitudeCompleteness().estimate([x["magnitude_homogeneous"] for x in transformed])
        flags=defaultdict(int)
        for x in transformed: flags[x["magnitude_method"]]+=1
        return transformed, CatalogQC(len(events),len(canonical),len(aliases),None if mc!=mc else mc,dict(flags)),aliases
