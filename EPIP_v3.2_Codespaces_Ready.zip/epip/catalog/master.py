from __future__ import annotations
from collections import defaultdict
from datetime import datetime
from epip.models import Event

class MasterCatalog:
    """Deterministic in-memory reconciliation layer; persistence is CatalogStore."""
    def __init__(self, events=None): self.events={}; self.aliases={}; self.add_many(events or [])
    def add(self,event:Event):
        key=(event.source,event.source_event_id)
        existing=self.events.get(key)
        if existing is None or (event.updated_at or event.origin_time) > (existing.updated_at or existing.origin_time):
            self.events[key]=event
        return self.events[key]
    def add_many(self,events):
        for e in events:self.add(e)
    def events_sorted(self): return sorted(self.events.values(),key=lambda e:e.origin_time)
    def filter(self,start=None,end=None,min_magnitude=None):
        return [e for e in self.events_sorted() if (start is None or e.origin_time>=start) and (end is None or e.origin_time<end) and (min_magnitude is None or e.magnitude>=min_magnitude)]
    def deduplicate_by_proximity(self, time_seconds=10, distance_km=10, magnitude_delta=0.2):
        from epip.geometry.association import haversine_km
        events=self.events_sorted(); keep=[]; replaced={}
        for e in events:
            duplicate=None
            for k in reversed(keep[-50:]):
                dt=abs((e.origin_time-k.origin_time).total_seconds())
                if dt>time_seconds: break
                if abs(e.magnitude-k.magnitude)<=magnitude_delta and haversine_km(e.latitude,e.longitude,k.latitude,k.longitude)<=distance_km:
                    duplicate=k; break
            if duplicate: replaced[e.event_id]=duplicate.event_id
            else: keep.append(e)
        return keep,replaced
