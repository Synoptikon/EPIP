from __future__ import annotations
from dataclasses import dataclass
from datetime import timedelta
import math
import numpy as np
from epip.models import Event
@dataclass(frozen=True)
class CompletenessResult:
    mc: float; method: str; n_events: int; uncertainty: float; coverage_start: str|None; coverage_end: str|None
class CompletenessEngine:
    def __init__(self,bin_width=.1,correction=.2): self.bin_width=bin_width; self.correction=correction
    def estimate(self,events,start=None,end=None):
        es=[e for e in events if (start is None or e.origin_time>=start) and (end is None or e.origin_time<=end)]
        mags=[e.magnitude for e in es if math.isfinite(e.magnitude)]
        if len(mags)<20: return CompletenessResult(float('nan'),'insufficient_events',len(mags),float('nan'),min((e.origin_time for e in es),default=None).isoformat() if es else None,max((e.origin_time for e in es),default=None).isoformat() if es else None)
        lo=math.floor(min(mags)/self.bin_width)*self.bin_width; hi=math.ceil(max(mags)/self.bin_width)*self.bin_width+self.bin_width; bins=np.arange(lo,hi+self.bin_width/2,self.bin_width); hist,_=np.histogram(mags,bins=bins); mc=float(bins[int(np.argmax(hist))]+self.correction)
        rng=np.random.default_rng(12345); a=np.asarray(mags); vals=[]
        for _ in range(200):
            s=rng.choice(a,size=len(a),replace=True); h,_=np.histogram(s,bins=bins); vals.append(bins[int(np.argmax(h))]+self.correction)
        return CompletenessResult(round(mc,3),'maximum_curvature+0.2',len(mags),round(float(np.std(vals,ddof=1)),3),min(e.origin_time for e in es).isoformat(),max(e.origin_time for e in es).isoformat())
    def temporal(self,events,window_days=30,end=None):
        if not events:return []
        end=end or max(e.origin_time for e in events); earliest=min(e.origin_time for e in events); cur=end; out=[]
        while cur>earliest:
            a=max(earliest,cur-timedelta(days=window_days)); r=self.estimate(events,a,cur); out.append({'start':a.isoformat(),'end':cur.isoformat(),'mc':r.mc,'uncertainty':r.uncertainty,'n_events':r.n_events}); cur=a
        return list(reversed(out))
