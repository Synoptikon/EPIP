from __future__ import annotations
from dataclasses import dataclass
import math
from collections import defaultdict
from epip.models import Event

@dataclass(frozen=True)
class MagnitudeRule:
    """Transparent empirical conversion rule: Mw-equivalent = a + b*M."""
    source_type: str
    a: float
    b: float = 1.0
    valid_min: float | None = None
    valid_max: float | None = None
    reference: str = "EPIP calibration rule"

    def applies(self, m: float) -> bool:
        return (self.valid_min is None or m >= self.valid_min) and (self.valid_max is None or m <= self.valid_max)

class MagnitudeHomogenizer:
    def __init__(self, rules: dict[str, MagnitudeRule] | None = None, default_uncertainty: float = 0.2):
        self.rules = {k.upper(): v for k, v in (rules or {}).items()}
        self.default_uncertainty = default_uncertainty

    def convert(self, magnitude: float, magnitude_type: str | None) -> tuple[float, float, str]:
        mt=(magnitude_type or "UNK").upper()
        rule=self.rules.get(mt)
        if rule and rule.applies(magnitude):
            return rule.a + rule.b*magnitude, self.default_uncertainty, f"rule:{mt}"
        if mt in {"MW", "MWW", "Mwc".upper()}:
            return magnitude, 0.0, "identity:MW"
        return magnitude, self.default_uncertainty, "unmapped"

    def transform(self, events: list[Event]) -> list[dict]:
        out=[]
        for e in events:
            mw,sigma,method=self.convert(e.magnitude,e.magnitude_type)
            out.append({"event":e,"magnitude_homogeneous":mw,"magnitude_sigma":sigma,"magnitude_method":method})
        return out

class MagnitudeCompleteness:
    """Mc via maximum curvature histogram, with conservative +0.2 correction."""
    def __init__(self, bin_width: float = 0.1, correction: float = 0.2):
        self.bin_width=bin_width; self.correction=correction
    def estimate(self, magnitudes: list[float]) -> float:
        if len(magnitudes)<20: return float("nan")
        x=sorted(float(m) for m in magnitudes if math.isfinite(m))
        lo=math.floor(min(x)/self.bin_width)*self.bin_width
        hi=math.ceil(max(x)/self.bin_width)*self.bin_width+self.bin_width
        edges=[lo+i*self.bin_width for i in range(int(round((hi-lo)/self.bin_width))+1)]
        hist=[]
        for a,b in zip(edges[:-1],edges[1:]): hist.append(sum(a<=m<b for m in x))
        if not hist: return float("nan")
        mc=edges[int(max(range(len(hist)),key=hist.__getitem__))]
        return round(mc+self.correction,3)
