from __future__ import annotations
import sqlite3, json
from pathlib import Path
from datetime import datetime, timezone
from epip.models import Event
from epip.data.provenance import Snapshot, snapshot_hash

SCHEMA = '''
CREATE TABLE IF NOT EXISTS events (
 event_id TEXT PRIMARY KEY, source TEXT NOT NULL, source_event_id TEXT NOT NULL,
 origin_time TEXT NOT NULL, latitude REAL NOT NULL, longitude REAL NOT NULL,
 depth_km REAL NOT NULL, magnitude REAL NOT NULL, magnitude_type TEXT,
 updated_at TEXT, catalog_version TEXT NOT NULL, raw_sha256 TEXT NOT NULL,
 normalized_sha256 TEXT NOT NULL, quality_flags TEXT NOT NULL DEFAULT '[]',
 UNIQUE(source, source_event_id)
);
CREATE INDEX IF NOT EXISTS idx_events_time ON events(origin_time);
CREATE INDEX IF NOT EXISTS idx_events_mag ON events(magnitude);
CREATE TABLE IF NOT EXISTS snapshots (
 snapshot_id TEXT PRIMARY KEY, source TEXT NOT NULL, source_version TEXT NOT NULL,
 retrieved_at TEXT NOT NULL, query_json TEXT NOT NULL, coverage_start TEXT,
 coverage_end TEXT, record_count INTEGER NOT NULL, sha256 TEXT NOT NULL,
 schema_version TEXT NOT NULL, quality_status TEXT NOT NULL
);
'''

def _iso(dt):
    if dt is None: return None
    if dt.tzinfo is None: dt=dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc).isoformat()

class CatalogStore:
    def __init__(self, path='data/epip.sqlite'):
        self.path=Path(path); self.path.parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.path) as c: c.executescript(SCHEMA)

    def upsert(self, events:list[Event]) -> int:
        inserted=0
        with sqlite3.connect(self.path) as c:
            for e in events:
                cur=c.execute('''INSERT OR IGNORE INTO events
                (event_id,source,source_event_id,origin_time,latitude,longitude,depth_km,magnitude,magnitude_type,updated_at,catalog_version,raw_sha256,normalized_sha256,quality_flags)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                (e.event_id,e.source,e.source_event_id,_iso(e.origin_time),e.latitude,e.longitude,e.depth_km,e.magnitude,e.magnitude_type,_iso(e.updated_at),e.catalog_version,e.raw_sha256,e.normalized_sha256,json.dumps(e.quality_flags,sort_keys=True)))
                inserted += cur.rowcount
        return inserted

    def query(self, start=None, end=None, min_magnitude=None, max_magnitude=None) -> list[Event]:
        clauses=[]; args=[]
        if start: clauses.append('origin_time >= ?'); args.append(_iso(start))
        if end: clauses.append('origin_time < ?'); args.append(_iso(end))
        if min_magnitude is not None: clauses.append('magnitude >= ?'); args.append(min_magnitude)
        if max_magnitude is not None: clauses.append('magnitude <= ?'); args.append(max_magnitude)
        sql='SELECT * FROM events'+((' WHERE '+' AND '.join(clauses)) if clauses else '')+' ORDER BY origin_time'
        with sqlite3.connect(self.path) as c:
            rows=c.execute(sql,args).fetchall()
        out=[]
        for r in rows:
            out.append(Event(event_id=r[0],source=r[1],source_event_id=r[2],origin_time=datetime.fromisoformat(r[3]),latitude=r[4],longitude=r[5],depth_km=r[6],magnitude=r[7],magnitude_type=r[8],updated_at=datetime.fromisoformat(r[9]) if r[9] else None,catalog_version=r[10],raw_sha256=r[11],normalized_sha256=r[12],quality_flags=json.loads(r[13])))
        return out

    def create_snapshot(self, source, source_version, query, events, quality_status='PASS') -> Snapshot:
        payload=[e.model_dump(mode='json') for e in events]
        sid='snap-'+snapshot_hash({'source':source,'version':source_version,'query':query,'events':payload})[:20]
        times=[e.origin_time for e in events]
        snap=Snapshot(snapshot_id=sid,source=source,source_version=source_version,retrieved_at=datetime.now(timezone.utc),query=query,coverage_start=min(times) if times else None,coverage_end=max(times) if times else None,record_count=len(events),sha256=snapshot_hash(payload),quality_status=quality_status)
        with sqlite3.connect(self.path) as c:
            c.execute('INSERT OR REPLACE INTO snapshots VALUES (?,?,?,?,?,?,?,?,?,?,?)',(snap.snapshot_id,snap.source,snap.source_version,_iso(snap.retrieved_at),json.dumps(snap.query,sort_keys=True),_iso(snap.coverage_start),_iso(snap.coverage_end),snap.record_count,snap.sha256,snap.schema_version,snap.quality_status))
        return snap

    def latest_snapshot(self):
        with sqlite3.connect(self.path) as c:
            r=c.execute('SELECT * FROM snapshots ORDER BY retrieved_at DESC LIMIT 1').fetchone()
        return r
