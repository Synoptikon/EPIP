from __future__ import annotations
from dataclasses import dataclass
from datetime import timedelta
from math import exp
from epip.geometry.association import haversine_km
from epip.models import Event

@dataclass(frozen=True)
class DeclusteringResult:
    background: list[Event]
    clustered: list[Event]
    parent: dict[str,str]

class WindowDeclusterer:
    """Deterministic screening declustering. Not a substitute for ETAS branching probabilities."""
    def __init__(self, time_days: float = 7.0, distance_km: float = 30.0, magnitude_scale: float = 1.0):
        self.time_days=time_days; self.distance_km=distance_km; self.magnitude_scale=magnitude_scale
    def run(self, events: list[Event]) -> DeclusteringResult:
        ordered=sorted(events,key=lambda e:e.origin_time); bg=[]; clustered=[]; parent={}
        for e in ordered:
            candidate=None
            for p in reversed(bg[-100:]):
                dt=(e.origin_time-p.origin_time).total_seconds()/86400
                if dt>self.time_days: break
                radius=self.distance_km*(10**(self.magnitude_scale*max(p.magnitude-4,0)))
                if haversine_km(e.latitude,e.longitude,p.latitude,p.longitude)<=radius:
                    candidate=p; break
            if candidate:
                clustered.append(e); parent[e.event_id]=candidate.event_id
            else: bg.append(e)
        return DeclusteringResult(bg,clustered,parent)
