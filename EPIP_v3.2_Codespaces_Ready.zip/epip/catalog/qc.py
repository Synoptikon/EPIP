from __future__ import annotations
from epip.models import Event

def quality_flags(event:Event, *, min_magnitude=-2, max_magnitude=10, max_depth_km=1000):
    flags=[]
    if not (-90<=event.latitude<=90): flags.append('LATITUDE_OUT_OF_RANGE')
    if not (-180<=event.longitude<=180): flags.append('LONGITUDE_OUT_OF_RANGE')
    if not (min_magnitude<=event.magnitude<=max_magnitude): flags.append('MAGNITUDE_OUT_OF_RANGE')
    if not (0<=event.depth_km<=max_depth_km): flags.append('DEPTH_OUT_OF_RANGE')
    return flags

def validate_catalog(events):
    return [(e,quality_flags(e)) for e in events]
