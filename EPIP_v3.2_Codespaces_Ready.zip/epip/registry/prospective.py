from __future__ import annotations
import json, sqlite3
from datetime import datetime, timezone
from epip.models import Forecast

class ProspectiveRegistry:
    def __init__(self,path='data/epip.sqlite'):
        self.path=path
        with sqlite3.connect(path) as c:
            c.execute('''CREATE TABLE IF NOT EXISTS forecasts (forecast_id TEXT PRIMARY KEY, payload_json TEXT NOT NULL, status TEXT NOT NULL, created_at TEXT NOT NULL)''')
            c.execute('''CREATE TABLE IF NOT EXISTS evaluations (evaluation_id TEXT PRIMARY KEY, forecast_id TEXT NOT NULL, payload_json TEXT NOT NULL, evaluated_at TEXT NOT NULL)''')
    def save(self, forecast:Forecast):
        with sqlite3.connect(self.path) as c:
            c.execute('INSERT OR REPLACE INTO forecasts VALUES (?,?,?,?)',(forecast.forecast_id,forecast.model_dump_json(),forecast.status,forecast.created_at.isoformat()))
    def transition(self, forecast_id, status):
        allowed={'CREATED':'VALIDATED','VALIDATED':'FROZEN','FROZEN':'WAITING','WAITING':'EVALUATED'}
        with sqlite3.connect(self.path) as c:
            r=c.execute('SELECT status,payload_json FROM forecasts WHERE forecast_id=?',(forecast_id,)).fetchone()
            if not r: raise KeyError(forecast_id)
            if allowed.get(r[0])!=status: raise ValueError(f'invalid transition {r[0]} -> {status}')
            payload=json.loads(r[1]); payload['status']=status
            c.execute('UPDATE forecasts SET status=?,payload_json=? WHERE forecast_id=?',(status,json.dumps(payload),forecast_id))
    def latest(self):
        with sqlite3.connect(self.path) as c:
            r=c.execute('SELECT payload_json,status FROM forecasts ORDER BY created_at DESC LIMIT 1').fetchone()
        return json.loads(r[0]) if r else None
