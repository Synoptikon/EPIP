from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Any, Iterable
import hashlib, json, math
import numpy as np
from pyproj import CRS, Transformer

SECONDS_PER_YEAR = 365.25 * 86400.0

@dataclass(frozen=True)
class StationVelocity:
    station_id: str
    latitude: float
    longitude: float
    east_mm_yr: float | None
    north_mm_yr: float | None
    up_mm_yr: float | None = None
    east_sigma_mm_yr: float | None = None
    north_sigma_mm_yr: float | None = None
    up_sigma_mm_yr: float | None = None
    n_observations: int = 0
    span_years: float = 0.0
    residual_rms_mm: float | None = None
    quality: str = "unknown"
    def to_dict(self): return asdict(self)

@dataclass(frozen=True)
class GeodeticState:
    station_count: int
    velocity_e_mm_yr: float | None
    velocity_n_mm_yr: float | None
    strain_exx: float | None
    strain_eyy: float | None
    strain_exy: float | None
    principal_strain_max: float | None
    principal_strain_min: float | None
    principal_azimuth_deg: float | None
    rotation_rad_yr: float | None
    residual_rms_mm_yr: float | None
    condition_number: float | None
    uncertainty: float | None
    snapshot_id: str
    strain_volumetric: float | None = None
    max_shear_strain: float | None = None
    n_dof: int | None = None
    quality: str = "insufficient"
    created_at: str = ""
    def to_dict(self): return asdict(self)

def strain_invariants(exx, eyy, exy):
    exx=float(exx); eyy=float(eyy); exy=float(exy)
    mean=(exx+eyy)/2.0
    radius=float(math.hypot((exx-eyy)/2.0, exy))
    return {
        'volumetric': float(exx+eyy),
        'max_shear': radius,
        'principal_max': mean+radius,
        'principal_min': mean-radius,
        'principal_azimuth_deg': float(np.degrees(0.5*np.arctan2(2*exy, exx-eyy))),
    }

def _local_transform(lats, lons):
    lat0=float(np.mean(lats)); lon0=float(np.mean(lons))
    crs=CRS.from_proj4(f"+proj=aeqd +lat_0={lat0} +lon_0={lon0} +datum=WGS84 +units=m +no_defs")
    return Transformer.from_crs('EPSG:4326',crs,always_xy=True)

def _linear_component(rows, key, min_points):
    vals=[]; ts=[]
    t0=rows[0]['timestamp']
    for r in rows:
        v=r.get(key)
        if v is None: continue
        vals.append(float(v)); ts.append((r['timestamp']-t0).total_seconds()/SECONDS_PER_YEAR)
    if len(vals)<min_points: return None, None, None, len(vals)
    t=np.asarray(ts,float); y=np.asarray(vals,float)
    X=np.column_stack([np.ones(len(t)),t])
    beta,resid_sum,_,_=np.linalg.lstsq(X,y,rcond=None)
    residual=y-X@beta
    dof=max(1,len(y)-2)
    sigma2=float((residual@residual)/dof)
    cov=sigma2*np.linalg.inv(X.T@X)
    return float(beta[1]), float(np.sqrt(max(cov[1,1],0))), float(np.sqrt(np.mean(residual**2))), len(vals)

def estimate_station_velocity(observations: Iterable[dict[str,Any]], *, min_points=4, min_span_years=1.0, robust=True):
    """Estimate E/N/U linear velocities in mm/yr. Outlier rejection uses MAD on detrended residuals."""
    groups={}
    for o in observations:
        row=dict(o)
        if not isinstance(row.get('timestamp'), datetime): row['timestamp']=datetime.fromisoformat(str(row['timestamp']).replace('Z','+00:00'))
        if row['timestamp'].tzinfo is None: row['timestamp']=row['timestamp'].replace(tzinfo=timezone.utc)
        groups.setdefault(str(row['station_id']),[]).append(row)
    out=[]
    for sid, rows in groups.items():
        rows=sorted(rows,key=lambda r:r['timestamp'])
        span=(rows[-1]['timestamp']-rows[0]['timestamp']).total_seconds()/SECONDS_PER_YEAR
        if len(rows)<min_points or span < min_span_years: continue
        rec={'station_id':sid,'latitude':float(rows[0]['latitude']),'longitude':float(rows[0]['longitude']),'n_observations':len(rows),'span_years':float(span)}
        rms=[]
        for comp in ('east_mm','north_mm','up_mm'):
            use=rows
            slope,sigma,r,used=_linear_component(use,comp,min_points)
            if robust and slope is not None:
                # One-pass MAD rejection against the fitted line.
                t0=rows[0]['timestamp']; ts=np.array([(x['timestamp']-t0).total_seconds()/SECONDS_PER_YEAR for x in use if x.get(comp) is not None])
                ys=np.array([float(x[comp]) for x in use if x.get(comp) is not None])
                pred=(ys-ts*np.mean([])) if False else None
                X=np.column_stack([np.ones(len(ts)),ts]); b=np.linalg.lstsq(X,ys,rcond=None)[0]; rr=ys-X@b
                med=np.median(rr); mad=np.median(np.abs(rr-med)); scale=max(1.4826*mad,1e-6)
                keep=np.abs(rr-med)<=4.5*scale
                if keep.sum()>=min_points and keep.sum()<len(rr):
                    filtered=[x for x in use if x.get(comp) is not None]
                    filtered=[x for x,k in zip(filtered,keep) if k]
                    slope,sigma,r,used=_linear_component(filtered,comp,min_points)
            rec[comp+'_yr']=slope; rec[comp.replace('_mm','')+'_sigma_mm_yr']=sigma
            if r is not None: rms.append(r)
        rec['residual_rms_mm']=float(np.sqrt(np.mean(np.square(rms)))) if rms else None
        rec['quality']='good' if span>=3 and len(rows)>=6 else 'usable'
        out.append(StationVelocity(**rec).to_dict())
    return out

def fit_velocity_strain(stations, *, snapshot_id='unknown', min_stations=4) -> GeodeticState:
    """Fit a first-order 2-D velocity field and derive strain/rotation in 1/yr."""
    rows=[s for s in stations if s.get('east_mm_yr') is not None and s.get('north_mm_yr') is not None]
    if len(rows)<min_stations:
        return GeodeticState(len(rows),None,None,None,None,None,None,None,None,None,None,None,None,snapshot_id,quality='insufficient',created_at=datetime.now(timezone.utc).isoformat())
    lats=[r['latitude'] for r in rows]; lons=[r['longitude'] for r in rows]
    tr=_local_transform(lats,lons)
    xy=np.array([tr.transform(r['longitude'],r['latitude']) for r in rows],float)
    x=(xy[:,0]-xy[:,0].mean())/1000.0; y=(xy[:,1]-xy[:,1].mean())/1000.0
    A=np.column_stack([np.ones(len(rows)),x,y])
    ve=np.array([r['east_mm_yr'] for r in rows],float); vn=np.array([r['north_mm_yr'] for r in rows],float)
    be=np.linalg.lstsq(A,ve,rcond=None)[0]; bn=np.linalg.lstsq(A,vn,rcond=None)[0]
    re=ve-A@be; rn=vn-A@bn
    # mm/yr per km = 1e-6 / yr
    exx=float(be[1]*1e-6); exy=float((be[2]+bn[1])*0.5e-6); eyy=float(bn[2]*1e-6)
    rotation=float((bn[1]-be[2])*0.5e-6)
    inv=strain_invariants(exx,eyy,exy)
    cond=float(np.linalg.cond(A)); rms=float(np.sqrt(np.mean(np.r_[re,rn]**2)))
    dof=max(1,2*len(rows)-6); uncertainty=float(rms/np.sqrt(dof))
    quality='good' if len(rows)>=6 and cond<1e4 else ('usable' if cond<1e6 else 'ill_conditioned')
    return GeodeticState(len(rows),float(np.mean(ve)),float(np.mean(vn)),exx,eyy,exy,inv['principal_max'],inv['principal_min'],inv['principal_azimuth_deg'],rotation,rms,cond,uncertainty,snapshot_id,inv['volumetric'],inv['max_shear'],dof,quality,datetime.now(timezone.utc).isoformat())

def snapshot_hash(records: Iterable[dict[str,Any]]) -> str:
    payload=json.dumps(list(records),sort_keys=True,separators=(',',':'),default=str).encode()
    return hashlib.sha256(payload).hexdigest()
