from __future__ import annotations
import csv, json
from pathlib import Path
from typing import Any
from .insar import normalize_insar

def read_json_or_csv(path: str|Path) -> list[dict[str,Any]]:
    p=Path(path)
    if p.suffix.lower()=='.json':
        obj=json.loads(p.read_text())
        return obj if isinstance(obj,list) else obj.get('records',obj.get('features',[]))
    with p.open(newline='',encoding='utf-8') as f: return list(csv.DictReader(f))

def load_gnss_observations(path):
    rows=read_json_or_csv(path)
    required={'station_id','timestamp','latitude','longitude','east_mm','north_mm'}
    missing=required-set(rows[0]) if rows else required
    if missing: raise ValueError(f'Missing GNSS fields: {sorted(missing)}')
    return rows

def load_insar_observations(path): return normalize_insar(read_json_or_csv(path))
