from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Iterable
import numpy as np

@dataclass(frozen=True)
class InSARObservation:
    latitude: float
    longitude: float
    deformation_mm: float
    sigma_mm: float | None = None
    acquisition_start: str | None = None
    acquisition_end: str | None = None
    track: str | None = None
    quality: str = 'unknown'
    def to_dict(self): return asdict(self)

def normalize_insar(records: Iterable[dict[str,Any]]) -> list[dict[str,Any]]:
    out=[]
    for r in records:
        lat=float(r['latitude']); lon=float(r['longitude']); d=float(r.get('deformation_mm',r.get('los_mm')))
        if not (-90<=lat<=90 and -180<=lon<=180): raise ValueError('Invalid InSAR coordinates')
        sigma=r.get('sigma_mm'); sigma=float(sigma) if sigma is not None else None
        q='good' if sigma is not None and sigma>0 else 'usable' if np.isfinite(d) else 'invalid'
        out.append(InSARObservation(lat,lon,d,sigma,r.get('acquisition_start'),r.get('acquisition_end'),r.get('track'),q).to_dict())
    return out

def summarize_insar(records: Iterable[dict[str,Any]]) -> dict[str,Any]:
    rows=normalize_insar(records); vals=np.array([r['deformation_mm'] for r in rows],float)
    return {'count':len(rows),'mean_mm':float(np.mean(vals)) if len(vals) else None,'std_mm':float(np.std(vals,ddof=1)) if len(vals)>1 else 0.0,'min_mm':float(np.min(vals)) if len(vals) else None,'max_mm':float(np.max(vals)) if len(vals) else None,'good_fraction':float(np.mean([r['quality']=='good' for r in rows])) if rows else 0.0}
