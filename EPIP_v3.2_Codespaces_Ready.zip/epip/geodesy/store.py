from __future__ import annotations
from pathlib import Path
import json, sqlite3
from .state import snapshot_hash

class GeodeticStore:
    def __init__(self, db_path='data/epip.sqlite'):
        self.db_path=Path(db_path); self.db_path.parent.mkdir(parents=True,exist_ok=True); self._init()
    def _init(self):
        with sqlite3.connect(self.db_path) as c:
            c.executescript('''
            CREATE TABLE IF NOT EXISTS geodetic_snapshots(snapshot_id TEXT PRIMARY KEY, source TEXT, source_version TEXT, retrieved_at TEXT, record_type TEXT, record_count INTEGER, sha256 TEXT, quality_status TEXT, metadata_json TEXT);
            CREATE TABLE IF NOT EXISTS station_velocities(snapshot_id TEXT, station_id TEXT, latitude REAL, longitude REAL, east_mm_yr REAL, north_mm_yr REAL, up_mm_yr REAL, east_sigma_mm_yr REAL, north_sigma_mm_yr REAL, up_sigma_mm_yr REAL, n_observations INTEGER, span_years REAL, residual_rms_mm REAL, quality TEXT, PRIMARY KEY(snapshot_id,station_id));
            CREATE TABLE IF NOT EXISTS geodetic_states(snapshot_id TEXT PRIMARY KEY, state_json TEXT);
            CREATE TABLE IF NOT EXISTS insar_observations(snapshot_id TEXT, latitude REAL, longitude REAL, deformation_mm REAL, sigma_mm REAL, acquisition_start TEXT, acquisition_end TEXT, track TEXT, quality TEXT);
            ''')
    def save_snapshot(self, snapshot_id, source, version, retrieved_at, record_type, records, quality_status='unknown', metadata=None):
        rows=list(records); h=snapshot_hash(rows)
        with sqlite3.connect(self.db_path) as c:
            c.execute('INSERT OR REPLACE INTO geodetic_snapshots VALUES (?,?,?,?,?,?,?,?,?)',(snapshot_id,source,version,retrieved_at,record_type,len(rows),h,quality_status,json.dumps(metadata or {},sort_keys=True)))
        return {'snapshot_id':snapshot_id,'record_count':len(rows),'sha256':h}
    def save_station_velocities(self,snapshot_id,stations):
        with sqlite3.connect(self.db_path) as c:
            for s in stations:
                c.execute('INSERT OR REPLACE INTO station_velocities VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(snapshot_id,s['station_id'],s['latitude'],s['longitude'],s.get('east_mm_yr'),s.get('north_mm_yr'),s.get('up_mm_yr'),s.get('east_sigma_mm_yr'),s.get('north_sigma_mm_yr'),s.get('up_sigma_mm_yr'),s.get('n_observations',0),s.get('span_years',0),s.get('residual_rms_mm'),s.get('quality','unknown')))
    def save_state(self,state):
        with sqlite3.connect(self.db_path) as c: c.execute('INSERT OR REPLACE INTO geodetic_states VALUES (?,?)',(state.snapshot_id,json.dumps(state.to_dict(),sort_keys=True)))
    def latest(self):
        with sqlite3.connect(self.db_path) as c:
            r=c.execute('SELECT * FROM geodetic_snapshots ORDER BY retrieved_at DESC LIMIT 1').fetchone()
        if not r: return None
        return {'snapshot_id':r[0],'source':r[1],'source_version':r[2],'retrieved_at':r[3],'record_type':r[4],'record_count':r[5],'sha256':r[6],'quality_status':r[7],'metadata':json.loads(r[8])}
