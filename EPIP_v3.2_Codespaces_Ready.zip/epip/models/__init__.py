from .schemas import Event, TectonicAssociation, GeodeticObservation, ForecastCell, Forecast, Evaluation
