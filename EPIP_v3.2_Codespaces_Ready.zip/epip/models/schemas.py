from __future__ import annotations
from datetime import datetime
from typing import Literal
from pydantic import BaseModel, Field, field_validator

class Event(BaseModel):
    event_id: str
    source: str
    source_event_id: str
    origin_time: datetime
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)
    depth_km: float = Field(ge=-10, le=1000)
    magnitude: float = Field(ge=-2, le=10)
    magnitude_type: str | None = None
    updated_at: datetime | None = None
    catalog_version: str
    raw_sha256: str
    normalized_sha256: str
    quality_flags: list[str] = []

class TectonicAssociation(BaseModel):
    event_id: str
    plate_id: str | None = None
    fault_id: str | None = None
    distance_to_fault_km: float | None = Field(default=None, ge=0)
    association_method: str
    confidence: float = Field(ge=0, le=1)
    geometry_version: str

class GeodeticObservation(BaseModel):
    station_id: str
    timestamp: datetime
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)
    east_mm: float | None = None
    north_mm: float | None = None
    up_mm: float | None = None
    sigma_e_mm: float | None = Field(default=None, ge=0)
    sigma_n_mm: float | None = Field(default=None, ge=0)
    sigma_u_mm: float | None = Field(default=None, ge=0)
    source: str
    snapshot_id: str

class ForecastCell(BaseModel):
    longitude: float
    latitude: float
    depth_km: float = Field(ge=0)
    magnitude_min: float
    magnitude_max: float
    probability: float = Field(ge=0, le=1)
    expected_count: float = Field(ge=0)
    uncertainty: float = Field(ge=0)

class Forecast(BaseModel):
    forecast_id: str
    model_id: str
    model_version: str
    created_at: datetime
    cutoff_time: datetime
    horizon_end: datetime
    region_id: str
    magnitude_min: float
    magnitude_max: float
    input_snapshot_ids: list[str]
    code_version: str
    parameter_hash: str
    status: Literal['CREATED','VALIDATED','FROZEN','WAITING','EVALUATED']
    cells: list[ForecastCell]

class Evaluation(BaseModel):
    forecast_id: str
    observed_events: int
    brier: float | None = Field(default=None, ge=0)
    log_loss: float | None = Field(default=None, ge=0)
    evaluated_at: datetime
    evaluator_version: str
