from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

class ModelStatus(str, Enum):
    CANDIDATE='candidate'; CHALLENGER='challenger'; CHAMPION='champion'; RETIRED='retired'

@dataclass
class ModelRecord:
    model_id: str
    version: str
    status: ModelStatus
    brier: float | None = None
    log_loss: float | None = None
    calibration_error: float | None = None
    evaluation_count: int = 0
    metadata: dict = field(default_factory=dict)

class ModelGovernance:
    def __init__(self): self.models={}
    def register(self, record): self.models[(record.model_id,record.version)] = record
    def eligible_champion(self, record, min_evaluations=20):
        if record.evaluation_count < min_evaluations: return False
        if record.brier is None or record.log_loss is None: return False
        return True
    def rank(self):
        eligible=[m for m in self.models.values() if self.eligible_champion(m)]
        return sorted(eligible,key=lambda m:(m.brier,m.log_loss))
