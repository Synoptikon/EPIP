from __future__ import annotations
from dataclasses import dataclass
from math import radians, sin, cos, sqrt, atan2

@dataclass(frozen=True)
class GeometryVersion:
    dataset: str
    version: str


def haversine_km(lat1, lon1, lat2, lon2):
    R=6371.0088
    p1,p2=radians(lat1),radians(lat2)
    dp=radians(lat2-lat1); dl=radians(lon2-lon1)
    a=sin(dp/2)**2+cos(p1)*cos(p2)*sin(dl/2)**2
    return 2*R*atan2(sqrt(a),sqrt(max(0,1-a)))

def associate_nearest_feature(lat, lon, features):
    """features: iterable of {'id': str, 'lat': float, 'lon': float}."""
    best=None
    for f in features:
        d=haversine_km(lat,lon,f['lat'],f['lon'])
        if best is None or d<best[0]: best=(d,f)
    return best
