# Geometry compatibility layer

This directory remains for backwards compatibility with v2.2. New production code lives in `epip/tectonics`.
