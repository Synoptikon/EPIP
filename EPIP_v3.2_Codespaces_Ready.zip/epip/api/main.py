from fastapi import FastAPI, HTTPException
from datetime import datetime, timezone
import os, sqlite3, json
from pathlib import Path
from epip.catalog.store import CatalogStore
from epip.registry.prospective import ProspectiveRegistry

VERSION='3.2.0'
DB=Path(os.getenv('EPIP_DB','data/epip.sqlite'))
store=CatalogStore(DB); registry=ProspectiveRegistry(DB)
app=FastAPI(title='EPIP',version=VERSION,description='Earthquake Probabilistic Intelligence Platform')

@app.get('/health')
def health(): return {'status':'ok','platform':'EPIP','version':VERSION,'time':datetime.now(timezone.utc).isoformat()}
@app.get('/catalog/latest')
def catalog_latest():
    events=store.query(); return {'count':len(events),'latest_event':events[-1].model_dump(mode='json') if events else None}
@app.get('/catalog/stats')
def catalog_stats():
    events=store.query(); return {'count':len(events),'min_magnitude':min((e.magnitude for e in events),default=None),'max_magnitude':max((e.magnitude for e in events),default=None),'sources':sorted(set(e.source for e in events))}
@app.get('/snapshots')
def snapshots(): return {'latest':store.latest_snapshot()}
@app.get('/forecast/latest')
def forecast_latest(): return registry.latest() or {'status':'not_initialized'}
@app.get('/models')
def models():
    return {'champion':os.getenv('EPIP_CHAMPION_MODEL','poisson-baseline'),'implemented':['poisson-baseline','etas','ensemble','state-rate'],'available_challengers':['etas','ensemble','state-rate'],'governance_policy':{'min_evaluations':20,'retrospective_selection':False,'prospective_freeze_required':True}}
@app.get('/evaluation/latest')
def evaluation_latest(): return {'status':'registry_ready'}
@app.get('/provenance/{snapshot_id}')
def provenance(snapshot_id:str):
    with sqlite3.connect(DB) as c: r=c.execute('SELECT * FROM snapshots WHERE snapshot_id=?',(snapshot_id,)).fetchone()
    if not r: raise HTTPException(404,'snapshot not found')
    return {'snapshot_id':r[0],'source':r[1],'source_version':r[2],'retrieved_at':r[3],'query':json.loads(r[4]),'coverage_start':r[5],'coverage_end':r[6],'record_count':r[7],'sha256':r[8],'schema_version':r[9],'quality_status':r[10]}

def _tectonic_engine():
    from epip.tectonics.geometry import GeometryStore
    from epip.tectonics.association import TectonicGeometryEngine
    pp=os.getenv('EPIP_PLATES_GEOJSON'); ff=os.getenv('EPIP_FAULTS_GEOJSON')
    if not pp: return None, {'status':'not_configured','message':'Set EPIP_PLATES_GEOJSON to a versioned plate GeoJSON.'}
    plates=GeometryStore.from_geojson(pp,dataset=os.getenv('EPIP_PLATES_DATASET','plates'),version=os.getenv('EPIP_PLATES_VERSION','unknown'),id_field=os.getenv('EPIP_PLATES_ID_FIELD'))
    faults=None
    if ff: faults=GeometryStore.from_geojson(ff,dataset=os.getenv('EPIP_FAULTS_DATASET','faults'),version=os.getenv('EPIP_FAULTS_VERSION','unknown'),id_field=os.getenv('EPIP_FAULTS_ID_FIELD'))
    return TectonicGeometryEngine(plates,faults), None

@app.get('/geometry/status')
def geometry_status():
    engine, err=_tectonic_engine()
    if err: return err
    return {'status':'ready','plates':engine.plates.manifest(),'faults':engine.faults.manifest() if engine.faults else None,'plate_validation':engine.plates.validate(),'fault_validation':engine.faults.validate() if engine.faults else None}
@app.get('/tectonic/associate/{event_id}')
def tectonic_associate(event_id:str, latitude:float, longitude:float, depth_km:float|None=None):
    engine, err=_tectonic_engine()
    if err: raise HTTPException(503,err['message'])
    if not (-90<=latitude<=90 and -180<=longitude<=180): raise HTTPException(400,'invalid coordinates')
    return engine.associate(event_id=event_id,latitude=latitude,longitude=longitude,depth_km=depth_km).to_dict()
@app.get('/tectonic/state/{event_id}')
def tectonic_state(event_id:str, latitude:float, longitude:float, depth_km:float|None=None):
    from epip.tectonics.state import build_tectonic_state
    engine, err=_tectonic_engine()
    if err: raise HTTPException(503,err['message'])
    assoc=engine.associate(event_id=event_id,latitude=latitude,longitude=longitude,depth_km=depth_km)
    return build_tectonic_state(event_id,assoc).to_dict()
@app.get('/geodesy/status')
def geodesy_status():
    from epip.geodesy.store import GeodeticStore
    return {'status':'ready','latest':GeodeticStore(DB).latest()}
@app.get('/geodesy/state/{snapshot_id}')
def geodesy_state(snapshot_id:str):
    with sqlite3.connect(DB) as c: r=c.execute('SELECT state_json FROM geodetic_states WHERE snapshot_id=?',(snapshot_id,)).fetchone()
    if not r: raise HTTPException(404,'geodetic state not found')
    return json.loads(r[0])
@app.get('/geodesy/stations/{snapshot_id}')
def geodesy_stations(snapshot_id:str):
    with sqlite3.connect(DB) as c: rows=c.execute('SELECT station_id,latitude,longitude,east_mm_yr,north_mm_yr,up_mm_yr,east_sigma_mm_yr,north_sigma_mm_yr,up_sigma_mm_yr,n_observations,span_years,residual_rms_mm,quality FROM station_velocities WHERE snapshot_id=?',(snapshot_id,)).fetchall()
    keys=['station_id','latitude','longitude','east_mm_yr','north_mm_yr','up_mm_yr','east_sigma_mm_yr','north_sigma_mm_yr','up_sigma_mm_yr','n_observations','span_years','residual_rms_mm','quality']
    return {'snapshot_id':snapshot_id,'count':len(rows),'stations':[dict(zip(keys,r)) for r in rows]}
@app.post('/stress/finite-fault')
def finite_fault_stress(payload:dict):
    try:
        from epip.stress import ElasticMedium, RectangularRupture, ReceiverFaultPlane, FiniteFaultStressEngine
        from epip.stress.backend import CutdeHalfspaceBackend
        r=RectangularRupture(rupture_id=str(payload['rupture_id']),geometry_version=str(payload.get('geometry_version','unknown')),center_east_m=float(payload.get('center_east_m',0)),center_north_m=float(payload.get('center_north_m',0)),top_depth_m=float(payload['top_depth_m']),length_m=float(payload['length_m']),width_m=float(payload['width_m']),strike_deg=float(payload['strike_deg']),dip_deg=float(payload['dip_deg']),rake_deg=float(payload['rake_deg']),slip_m=float(payload['slip_m']),medium=ElasticMedium(float(payload.get('shear_modulus_pa',30e9)),float(payload.get('poisson_ratio',0.25))),source_event_id=payload.get('source_event_id'),source_provenance=payload.get('source_provenance'))
        receiver=ReceiverFaultPlane(receiver_id=str(payload['receiver_id']),east_m=float(payload['receiver_east_m']),north_m=float(payload['receiver_north_m']),depth_m=float(payload['receiver_depth_m']),strike_deg=float(payload['receiver_strike_deg']),dip_deg=float(payload['receiver_dip_deg']),rake_deg=float(payload['receiver_rake_deg']),friction=float(payload.get('friction',0.6)))
        return FiniteFaultStressEngine(CutdeHalfspaceBackend()).compute(r,receiver).__dict__
    except KeyError as exc: raise HTTPException(400,f'missing field: {exc.args[0]}')
    except RuntimeError as exc: raise HTTPException(503,str(exc))
    except ValueError as exc: raise HTTPException(400,str(exc))
@app.post('/state/fuse')
def fuse_state(payload:dict):
    from epip.fusion import fuse_observable_state, ObservableStateStore
    state=fuse_observable_state(event_id=payload.get('event_id'),tectonic=payload.get('tectonic'),geodetic=payload.get('geodetic'),stress=payload.get('stress'),input_snapshot_ids=payload.get('input_snapshot_ids'),state_version=VERSION)
    ObservableStateStore(DB).save(state); return state.to_dict()
@app.get('/state/latest')
def state_latest():
    from epip.fusion import ObservableStateStore
    return ObservableStateStore(DB).latest() or {'status':'not_initialized'}
@app.get('/state/{state_id}')
def state_get(state_id:str):
    from epip.fusion import ObservableStateStore
    state=ObservableStateStore(DB).get(state_id)
    if not state: raise HTTPException(404,'observable state not found')
    return state


@app.get('/experiments')
def experiments():
    from epip.experiments.registry import ExperimentRegistry
    return {'experiments':[dict(zip(['experiment_id','status','created_at','frozen_at'],r)) for r in ExperimentRegistry(DB).list()]}

@app.get('/experiments/{experiment_id}')
def experiment_get(experiment_id:str):
    from epip.experiments.registry import ExperimentRegistry
    r=ExperimentRegistry(DB).get(experiment_id)
    if not r: raise HTTPException(404,'experiment not found')
    return {'spec':json.loads(r[0]),'status':r[1],'frozen_at':r[2]}

@app.get('/completeness')
def completeness():
    from epip.catalog.completeness import CompletenessEngine
    events=store.query(); r=CompletenessEngine().estimate(events)
    d=r.__dict__.copy()
    for k,v in list(d.items()):
        if isinstance(v,float) and v != v: d[k]=None
    return d
