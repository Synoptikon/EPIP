from __future__ import annotations
from datetime import datetime, timezone
from epip.models import Event
from epip.core.hashing import sha256_json

def normalize_event(source, source_event_id, *, origin_time, latitude, longitude, depth_km, magnitude, magnitude_type=None, catalog_version='unknown', raw_payload=None, updated_at=None):
    if origin_time.tzinfo is None: origin_time=origin_time.replace(tzinfo=timezone.utc)
    raw_hash=sha256_json(raw_payload if raw_payload is not None else {'source':source,'source_event_id':source_event_id})
    normalized={'source':source,'source_event_id':source_event_id,'origin_time':origin_time.isoformat(),'latitude':float(latitude),'longitude':float(longitude),'depth_km':float(depth_km),'magnitude':float(magnitude),'magnitude_type':magnitude_type}
    return Event(event_id=f'{source}:{source_event_id}',source=source,source_event_id=source_event_id,origin_time=origin_time,latitude=float(latitude),longitude=float(longitude),depth_km=float(depth_km),magnitude=float(magnitude),magnitude_type=magnitude_type,updated_at=updated_at,catalog_version=catalog_version,raw_sha256=raw_hash,normalized_sha256=sha256_json(normalized),quality_flags=[])
