
from __future__ import annotations
from datetime import datetime, timezone
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
import json, hashlib, time
from epip.models import Event

BASE='https://earthquake.usgs.gov/fdsnws/event/1/query'
MAX_LIMIT=20000

class USGSComCatClient:
    source='USGS_COMCAT'
    version='FDSN-Event-1'
    def __init__(self, timeout=30, retries=4, backoff=1.5, user_agent='EPIP/3.2.0'):
        self.timeout=timeout; self.retries=retries; self.backoff=backoff; self.user_agent=user_agent

    def _request(self, params):
        url=BASE+'?'+urlencode(params)
        last=None
        for attempt in range(self.retries+1):
            try:
                req=Request(url,headers={'User-Agent':self.user_agent,'Accept':'application/json'})
                with urlopen(req,timeout=self.timeout) as r:
                    status=getattr(r,'status',200)
                    if status != 200: raise RuntimeError(f'USGS HTTP {status}')
                    return json.load(r), url
            except (HTTPError, URLError, TimeoutError, OSError, json.JSONDecodeError) as exc:
                last=exc
                if attempt>=self.retries: break
                time.sleep(self.backoff**attempt)
        raise RuntimeError(f'USGS request failed after {self.retries+1} attempts: {last}')

    @staticmethod
    def _event(feature, raw_version):
        p=feature.get('properties') or {}; g=feature.get('geometry') or {}; coords=g.get('coordinates') or []
        if len(coords)<3 or p.get('time') is None or p.get('mag') is None: return None
        raw=json.dumps(feature,sort_keys=True,separators=(',',':')).encode(); raw_hash=hashlib.sha256(raw).hexdigest()
        origin=datetime.fromtimestamp(p['time']/1000,tz=timezone.utc); eid=str(feature.get('id'))
        normalized={'source':'USGS_COMCAT','source_event_id':eid,'origin_time':origin.isoformat(),'latitude':coords[1],'longitude':coords[0],'depth_km':coords[2],'magnitude':p['mag'],'magnitude_type':p.get('magType')}
        norm_hash=hashlib.sha256(json.dumps(normalized,sort_keys=True,separators=(',',':')).encode()).hexdigest()
        return Event(event_id=f'USGS_COMCAT:{eid}',source='USGS_COMCAT',source_event_id=eid,origin_time=origin,latitude=float(coords[1]),longitude=float(coords[0]),depth_km=float(coords[2]),magnitude=float(p['mag']),magnitude_type=p.get('magType'),updated_at=datetime.fromtimestamp(p['updated']/1000,tz=timezone.utc) if p.get('updated') else None,catalog_version=str(raw_version or 'unknown'),raw_sha256=raw_hash,normalized_sha256=norm_hash,quality_flags=[])

    def fetch(self, *, starttime, endtime, minmagnitude=0.0, maxmagnitude=10.0, minlatitude=None, maxlatitude=None, minlongitude=None, maxlongitude=None, limit=MAX_LIMIT):
        limit=min(max(int(limit),1),MAX_LIMIT); offset=1; events=[]; pages=0; metadata={}
        base={'format':'geojson','starttime':starttime.isoformat(),'endtime':endtime.isoformat(),'minmagnitude':minmagnitude,'maxmagnitude':maxmagnitude,'limit':limit,'orderby':'time-asc'}
        for k,v in [('minlatitude',minlatitude),('maxlatitude',maxlatitude),('minlongitude',minlongitude),('maxlongitude',maxlongitude)]:
            if v is not None: base[k]=v
        while True:
            params={**base,'offset':offset}
            payload,url=self._request(params); pages+=1; metadata=payload.get('metadata',{}) or {}
            features=payload.get('features',[]) or []
            for f in features:
                e=self._event(f,metadata.get('generated'))
                if e is not None: events.append(e)
            if len(features)<limit: break
            offset += len(features)
            if offset>1_000_000: raise RuntimeError('USGS pagination safety limit exceeded')
        metadata=dict(metadata); metadata.update({'pages':pages,'records_fetched':len(events),'query_url':BASE})
        return events, metadata
