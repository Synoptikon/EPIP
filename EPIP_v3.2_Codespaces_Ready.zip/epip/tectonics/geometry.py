from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable
import hashlib, json

from shapely.geometry import shape, mapping, Point
from shapely.strtree import STRtree
from shapely.validation import explain_validity

@dataclass(frozen=True)
class GeometryFeature:
    feature_id: str
    geometry: Any
    properties: dict[str, Any] = field(default_factory=dict)

@dataclass
class GeometryStore:
    dataset: str
    version: str
    crs: str = "EPSG:4326"
    features: list[GeometryFeature] = field(default_factory=list)
    source_uri: str | None = None
    source_sha256: str | None = None

    def __post_init__(self):
        self._tree = STRtree([f.geometry for f in self.features]) if self.features else None
        self._index = {id(f.geometry): f for f in self.features}

    @classmethod
    def from_geojson(cls, path: str | Path, *, dataset: str, version: str, id_field: str | None = None, source_uri: str | None = None) -> "GeometryStore":
        p = Path(path)
        raw = p.read_bytes()
        obj = json.loads(raw)
        if obj.get("type") != "FeatureCollection":
            raise ValueError("Expected GeoJSON FeatureCollection")
        features=[]
        for i, item in enumerate(obj.get("features", [])):
            geom = shape(item["geometry"])
            if geom.is_empty:
                continue
            props = dict(item.get("properties") or {})
            raw_id = item.get("id") or (props.get(id_field) if id_field else None) or props.get("id") or props.get("fault_id") or props.get("faultId") or props.get("plate_id") or props.get("plateId") or i
            fid = str(raw_id)
            features.append(GeometryFeature(fid, geom, dict(item.get("properties") or {})))
        return cls(dataset, version, str(obj.get("crs", {}).get("properties", {}).get("name", "EPSG:4326")), features, source_uri, hashlib.sha256(raw).hexdigest())

    @classmethod
    def from_features(cls, features: Iterable[dict[str, Any]], *, dataset: str, version: str, crs: str = "EPSG:4326") -> "GeometryStore":
        fs=[]
        for i, f in enumerate(features):
            geom = f.get("geometry")
            if not hasattr(geom, "geom_type"):
                geom = shape(geom)
            props=dict(f.get("properties", {})); fid=f.get("id") or (props.get(id_field) if id_field else None) or props.get("id") or props.get("fault_id") or props.get("faultId") or props.get("plate_id") or props.get("plateId") or i; fs.append(GeometryFeature(str(fid), geom, props))
        return cls(dataset, version, crs, fs)

    def validate(self) -> dict[str, Any]:
        invalid=[]
        empty=[]
        for f in self.features:
            if f.geometry.is_empty: empty.append(f.feature_id)
            elif not f.geometry.is_valid: invalid.append({"id": f.feature_id, "reason": explain_validity(f.geometry)})
        return {"dataset":self.dataset,"version":self.version,"feature_count":len(self.features),"empty":empty,"invalid":invalid,"valid":not empty and not invalid}

    def query(self, geometry, predicate: str | None = None) -> list[GeometryFeature]:
        if not self._tree: return []
        hits = self._tree.query(geometry, predicate=predicate) if predicate else self._tree.query(geometry)
        out=[]
        for h in hits:
            f = self.features[int(h)] if hasattr(h, "__index__") else self._index.get(id(h))
            if f is not None: out.append(f)
        return out

    def nearest(self, geometry) -> GeometryFeature | None:
        if not self._tree: return None
        h=self._tree.nearest(geometry)
        try:
            return self.features[int(h)]
        except (TypeError, ValueError, IndexError):
            return self._index.get(id(h))

    def manifest(self) -> dict[str, Any]:
        return {"dataset":self.dataset,"version":self.version,"crs":self.crs,"feature_count":len(self.features),"source_uri":self.source_uri,"source_sha256":self.source_sha256}
