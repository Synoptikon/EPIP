from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any
from .association import TectonicGeometryEngine

@dataclass(frozen=True)
class TectonicState:
    event_id: str
    plate_id: str | None
    fault_id: str | None
    boundary_type: str | None
    fault_type: str | None
    distance_to_fault_km: float | None
    distance_to_boundary_km: float | None
    fault_strike_deg: float | None
    fault_dip_deg: float | None
    fault_rake_deg: float | None
    slip_rate_mm_yr: float | None
    relative_velocity_mm_yr: float | None
    association_confidence: float
    geometry_version: str
    source_provenance: dict[str, Any]

    def to_dict(self): return asdict(self)

def _scalar(props, *keys):
    for k in keys:
        v=props.get(k)
        if isinstance(v,(int,float)): return float(v)
        if isinstance(v,str):
            try: return float(v.strip().split(',')[0].replace('(','').replace(')',''))
            except ValueError: pass
    return None

def build_tectonic_state(event_id: str, association, *, relative_velocity_mm_yr: float | None = None) -> TectonicState:
    fp=association.fault_properties; pp=association.plate_properties
    ss=_scalar(fp,'slip_rate_mm_yr','slip_rate','strike_slip_rate','shortening_rate')
    return TectonicState(event_id,association.plate_id,association.fault_id,pp.get('boundary_type'),fp.get('slip_type') or fp.get('fault_type'),association.distance_to_fault_km,association.distance_to_boundary_km,_scalar(fp,'strike','average_strike'),_scalar(fp,'dip','average_dip'),_scalar(fp,'rake','average_rake'),ss,relative_velocity_mm_yr,association.association_confidence,association.geometry_version,{'fault':fp.get('source') or fp.get('reference'),'plate':pp.get('source') or pp.get('reference')})
