from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import json

@dataclass(frozen=True)
class GeometrySource:
    name: str
    role: str
    uri: str
    format: str
    license: str
    notes: str

SOURCES = [
    GeometrySource('GEM-GAF-DB','active_faults','https://github.com/GEMScienceTools/gem-global-active-faults','GeoJSON/GeoPackage','CC-BY-SA-4.0','Global active-fault traces and kinematic/slip-rate metadata.'),
    GeometrySource('GPlates/EarthByte','plate_reconstruction','https://www.gplates.org/download/','GPML/GeoJSON/Shapefile','dataset-specific','Use an explicitly versioned plate model; do not rely on the mutable default model.'),
    GeometrySource('USGS-QFaults','regional_faults_us','https://www.usgs.gov/programs/earthquake-hazards/faults','GIS/KML','Public Domain','US Quaternary faults; simplified fault-source geometry and metadata.'),
]

def manifest(): return [s.__dict__ for s in SOURCES]

def write_manifest(path: str|Path):
    Path(path).write_text(json.dumps({'geometry_sources':manifest()},indent=2),encoding='utf-8')
