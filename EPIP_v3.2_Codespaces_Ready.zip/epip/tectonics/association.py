from __future__ import annotations
from dataclasses import dataclass, asdict
from math import exp
from typing import Any

from pyproj import CRS, Transformer
from shapely.geometry import Point
from .geometry import GeometryStore, GeometryFeature

@dataclass(frozen=True)
class AssociationResult:
    event_id: str
    plate_id: str | None
    fault_id: str | None
    distance_to_fault_km: float | None
    distance_to_boundary_km: float | None
    fault_score: float
    plate_confidence: float
    association_confidence: float
    method: str
    geometry_version: str
    fault_properties: dict[str, Any]
    plate_properties: dict[str, Any]

    def to_dict(self): return asdict(self)

class TectonicGeometryEngine:
    def __init__(self, plates: GeometryStore, faults: GeometryStore | None = None, *, fault_scale_km: float = 25.0):
        self.plates=plates; self.faults=faults; self.fault_scale_km=fault_scale_km

    @staticmethod
    def _local_transformers(lat: float, lon: float):
        local = CRS.from_proj4(f"+proj=aeqd +lat_0={lat} +lon_0={lon} +datum=WGS84 +units=m +no_defs")
        return Transformer.from_crs("EPSG:4326", local, always_xy=True), Transformer.from_crs(local, "EPSG:4326", always_xy=True)

    def _distance_km(self, point: Point, geom) -> float:
        fwd,_ = self._local_transformers(point.y, point.x)
        from shapely.geometry import Point as ShapelyPoint
        p=ShapelyPoint(*fwd.transform(point.x,point.y)); g=__import__('shapely.ops',fromlist=['transform']).transform(fwd.transform, geom)
        return p.distance(g)/1000.0

    def associate(self, *, event_id: str, latitude: float, longitude: float, depth_km: float | None = None) -> AssociationResult:
        point=Point(longitude,latitude)
        plate=self._plate(point)
        fault=None; fault_dist=None; fault_score=0.0
        if self.faults and self.faults.features:
            candidates=self.faults.query(point.buffer(1.0)) or []
            if not candidates:
                candidates=[self.faults.nearest(point)] if self.faults.nearest(point) else []
            scored=[]
            for f in candidates:
                d=self._distance_km(point,f.geometry)
                depth_ok=self._depth_factor(depth_km,f.properties)
                score=exp(-d/max(self.fault_scale_km,1e-6))*depth_ok
                scored.append((score,d,f))
            if scored:
                fault_score,fault_dist,f=max(scored,key=lambda x:x[0])
                fault=f
        plate_conf=self._plate_confidence(point,plate)
        combined=0.65*fault_score+0.35*plate_conf if fault else plate_conf
        return AssociationResult(event_id, plate.feature_id if plate else None, fault.feature_id if fault else None, fault_dist, self._distance_to_plate_boundary(point,plate) if plate else None, fault_score, plate_conf, max(0,min(1,combined)), "spatial_geometry_v1", f"{self.plates.version}|{self.faults.version if self.faults else 'none'}", fault.properties if fault else {}, plate.properties if plate else {})

    def _plate(self, point):
        hits=self.plates.query(point, predicate="intersects")
        if hits: return hits[0]
        return self.plates.nearest(point)

    def _plate_confidence(self, point, plate):
        if not plate: return 0.0
        if plate.geometry.contains(point): return 1.0
        return 0.25

    def _distance_to_plate_boundary(self, point, plate):
        if not plate: return None
        boundary=plate.geometry.boundary
        return self._distance_km(point,boundary)

    @staticmethod
    def _depth_factor(depth_km, props):
        if depth_km is None: return 1.0
        dmin=props.get("depth_min_km", props.get("min_depth_km")); dmax=props.get("depth_max_km", props.get("max_depth_km"))
        try:
            if dmin is not None and depth_km < float(dmin): return 0.25
            if dmax is not None and depth_km > float(dmax): return 0.25
        except (TypeError,ValueError): pass
        return 1.0
