from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Any
import hashlib, json, math


def _finite(v):
    return v is not None and isinstance(v, (int, float)) and math.isfinite(float(v))


def _bounded(v, lo=0.0, hi=1.0, default=None):
    if not _finite(v): return default
    return max(lo, min(hi, float(v)))


def _quality_score(*, tectonic=None, geodetic=None, stress=None):
    vals=[]
    if tectonic is not None:
        vals.append(_bounded(tectonic.get('association_confidence'), default=0.0))
    if geodetic is not None:
        q=geodetic.get('quality','insufficient')
        vals.append({'good':1.0,'usable':0.75,'ill_conditioned':0.35,'insufficient':0.0}.get(q,0.25))
    if stress is not None:
        vals.append(1.0 if stress.get('validated') else 0.0)
    return float(sum(vals)/len(vals)) if vals else 0.0

@dataclass(frozen=True)
class ObservableEarthState:
    state_id: str
    event_id: str | None
    created_at: str
    state_version: str
    tectonic: dict[str, Any]
    geodetic: dict[str, Any]
    stress: dict[str, Any]
    features: dict[str, float | None]
    uncertainty: dict[str, float | None]
    quality_score: float
    quality_flags: list[str]
    input_snapshot_ids: list[str]
    provenance_hash: str

    def to_dict(self): return asdict(self)


def _feature(name, value, uncertainty, features, uncertainties):
    features[name] = float(value) if _finite(value) else None
    uncertainties[name] = float(uncertainty) if _finite(uncertainty) and float(uncertainty) >= 0 else None


def fuse_observable_state(*, event_id: str | None = None, tectonic: dict[str, Any] | None = None,
                          geodetic: dict[str, Any] | None = None, stress: dict[str, Any] | None = None,
                          input_snapshot_ids: list[str] | None = None, state_version='2.6.0') -> ObservableEarthState:
    """Create a provenance-preserving observable Earth-system state.

    This is feature/state fusion, not a causal earthquake forecast. Missing inputs remain missing.
    No imputation or invented physical signal is introduced.
    """
    tectonic=tectonic or {}; geodetic=geodetic or {}; stress=stress or {}
    features={}; uncertainties={}; flags=[]
    _feature('distance_to_fault_km', tectonic.get('distance_to_fault_km'), None, features, uncertainties)
    _feature('distance_to_boundary_km', tectonic.get('distance_to_boundary_km'), None, features, uncertainties)
    _feature('slip_rate_mm_yr', tectonic.get('slip_rate_mm_yr'), None, features, uncertainties)
    _feature('relative_velocity_mm_yr', tectonic.get('relative_velocity_mm_yr'), None, features, uncertainties)
    _feature('strain_exx_yr', geodetic.get('strain_exx'), geodetic.get('uncertainty'), features, uncertainties)
    _feature('strain_eyy_yr', geodetic.get('strain_eyy'), geodetic.get('uncertainty'), features, uncertainties)
    _feature('strain_exy_yr', geodetic.get('strain_exy'), geodetic.get('uncertainty'), features, uncertainties)
    _feature('principal_strain_max_yr', geodetic.get('principal_strain_max'), geodetic.get('uncertainty'), features, uncertainties)
    _feature('principal_strain_min_yr', geodetic.get('principal_strain_min'), geodetic.get('uncertainty'), features, uncertainties)
    _feature('max_shear_strain_yr', geodetic.get('max_shear_strain'), geodetic.get('uncertainty'), features, uncertainties)
    _feature('rotation_rad_yr', geodetic.get('rotation_rad_yr'), geodetic.get('uncertainty'), features, uncertainties)
    _feature('delta_cfs_pa', stress.get('delta_cfs_pa'), stress.get('uncertainty_pa'), features, uncertainties)

    if not tectonic: flags.append('TECTONIC_STATE_MISSING')
    elif _bounded(tectonic.get('association_confidence'), default=0.0) < 0.5: flags.append('LOW_TECTONIC_ASSOCIATION_CONFIDENCE')
    if not geodetic: flags.append('GEODETIC_STATE_MISSING')
    elif geodetic.get('quality') in {'insufficient','ill_conditioned'}: flags.append('LOW_GEODETIC_QUALITY')
    if not stress: flags.append('STRESS_STATE_MISSING')
    elif not stress.get('validated', False): flags.append('STRESS_NOT_VALIDATED')
    if not any(v is not None for v in features.values()): flags.append('NO_PHYSICAL_FEATURES')

    payload={'event_id':event_id,'state_version':state_version,'tectonic':tectonic,'geodetic':geodetic,'stress':stress,
             'features':features,'uncertainty':uncertainties,'input_snapshot_ids':sorted(input_snapshot_ids or [])}
    ph=hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(',',':'),default=str).encode()).hexdigest()
    state_id='oes_'+ph[:20]
    return ObservableEarthState(state_id,event_id,datetime.now(timezone.utc).isoformat(),state_version,
                                tectonic,geodetic,stress,features,uncertainties,_quality_score(tectonic=tectonic,geodetic=geodetic,stress=stress),flags,sorted(input_snapshot_ids or []),ph)
