from __future__ import annotations
from pathlib import Path
import json, sqlite3
from .state import ObservableEarthState

class ObservableStateStore:
    def __init__(self, db_path: str|Path):
        self.db_path=Path(db_path); self.db_path.parent.mkdir(parents=True,exist_ok=True); self._init()
    def _init(self):
        with sqlite3.connect(self.db_path) as c:
            c.execute('''CREATE TABLE IF NOT EXISTS observable_states (
                state_id TEXT PRIMARY KEY,event_id TEXT,created_at TEXT,state_version TEXT,
                state_json TEXT NOT NULL,provenance_hash TEXT NOT NULL,quality_score REAL NOT NULL)''')
            c.execute('CREATE INDEX IF NOT EXISTS idx_observable_states_event ON observable_states(event_id)')
            c.execute('CREATE INDEX IF NOT EXISTS idx_observable_states_created ON observable_states(created_at)')
    def save(self,state: ObservableEarthState):
        with sqlite3.connect(self.db_path) as c:
            c.execute('INSERT OR REPLACE INTO observable_states VALUES (?,?,?,?,?,?,?)',
                      (state.state_id,state.event_id,state.created_at,state.state_version,json.dumps(state.to_dict(),sort_keys=True),state.provenance_hash,state.quality_score))
    def get(self,state_id):
        with sqlite3.connect(self.db_path) as c:
            r=c.execute('SELECT state_json FROM observable_states WHERE state_id=?',(state_id,)).fetchone()
        return json.loads(r[0]) if r else None
    def latest(self):
        with sqlite3.connect(self.db_path) as c:
            r=c.execute('SELECT state_json FROM observable_states ORDER BY created_at DESC LIMIT 1').fetchone()
        return json.loads(r[0]) if r else None
