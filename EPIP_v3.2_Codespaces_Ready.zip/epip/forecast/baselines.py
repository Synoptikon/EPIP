from __future__ import annotations
from math import log
from epip.models import Event

def poisson_rate(events:list[Event], area_km2:float, days:float, magnitude_min:float)->float:
    n=sum(e.magnitude>=magnitude_min for e in events)
    return n/max(area_km2*days,1e-12)

def poisson_probability(events:list[Event], area_km2:float, days:float, cell_area_km2:float, magnitude_min:float)->float:
    lam=poisson_rate(events,area_km2,days,magnitude_min)*cell_area_km2*days
    from math import exp
    return 1-exp(-lam)
