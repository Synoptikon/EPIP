from datetime import datetime
from epip.models import Forecast
from epip.core.validation import require_temporal_cutoff

def validate_forecast(forecast: Forecast) -> Forecast:
    if forecast.horizon_end <= forecast.cutoff_time:
        raise ValueError('horizon_end must be after cutoff_time')
    for c in forecast.cells:
        if not 0 <= c.probability <= 1:
            raise ValueError('invalid probability')
    forecast.status = 'VALIDATED'
    return forecast

def freeze_forecast(forecast: Forecast) -> Forecast:
    if forecast.status != 'VALIDATED':
        raise ValueError('forecast must be validated before freezing')
    forecast.status = 'FROZEN'
    return forecast

def check_observation_cutoff(observation_time: datetime, forecast: Forecast) -> None:
    require_temporal_cutoff(observation_time, forecast.cutoff_time)
