from __future__ import annotations
from datetime import datetime
from math import exp
import numpy as np
from epip.models import Forecast, ForecastCell
from epip.core.hashing import sha256_json
from epip.core.validation import utcnow

class PoissonBaseline:
    """Transparent baseline: probability of >=1 event from expected count lambda."""
    model_id = 'poisson-baseline'
    model_version = '1.0.0'

    def forecast(self, *, cutoff_time: datetime, horizon_end: datetime,
                 region_id: str, cells: list[dict], input_snapshot_ids: list[str],
                 rate_per_cell: np.ndarray, magnitude_min: float,
                 magnitude_max: float, code_version: str = 'epip-3.0.0') -> Forecast:
        rate = np.asarray(rate_per_cell, dtype=float)
        if np.any(~np.isfinite(rate)) or np.any(rate < 0):
            raise ValueError('invalid Poisson rates')
        out=[]
        for c, lam in zip(cells, rate):
            p = float(1 - exp(-float(lam)))
            out.append(ForecastCell(**c, magnitude_min=magnitude_min,
                magnitude_max=magnitude_max, probability=p,
                expected_count=float(lam), uncertainty=float(np.sqrt(lam))))
        fid = 'fcst-' + sha256_json({'model':self.model_id,'cutoff':cutoff_time,
            'horizon':horizon_end,'region':region_id,'snapshots':input_snapshot_ids})[:20]
        return Forecast(forecast_id=fid, model_id=self.model_id,
            model_version=self.model_version, created_at=utcnow(),
            cutoff_time=cutoff_time, horizon_end=horizon_end, region_id=region_id,
            magnitude_min=magnitude_min, magnitude_max=magnitude_max,
            input_snapshot_ids=input_snapshot_ids, code_version=code_version,
            parameter_hash=sha256_json(rate.tolist()), status='CREATED', cells=out)
