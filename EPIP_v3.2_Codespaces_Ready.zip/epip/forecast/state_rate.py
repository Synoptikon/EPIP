from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from scipy.optimize import minimize
from epip.models import Forecast, ForecastCell
from epip.core.hashing import sha256_json
from epip.core.validation import utcnow

@dataclass(frozen=True)
class StateRateParameters:
    intercept: float
    coefficients: tuple[float, ...]
    l2: float

class StateRateModel:
    """Poisson log-linear challenger activated only with frozen state features."""
    model_id='state-rate'; model_version='1.0.0'
    def fit(self,X,counts,exposure=None,l2=1.0,maxiter=500):
        X=np.asarray(X,float); y=np.asarray(counts,float)
        off=np.zeros(len(y)) if exposure is None else np.log(np.maximum(np.asarray(exposure,float),1e-12))
        if X.ndim!=2 or y.ndim!=1 or len(y)!=len(X) or not np.isfinite(X).all() or np.any(y<0): raise ValueError('invalid training data')
        X1=np.column_stack([np.ones(len(X)),X])
        def nll(beta):
            eta=np.clip(X1@beta+off,-30,30); lam=np.exp(eta)
            return float(np.sum(lam-y*eta)+l2*np.sum(beta[1:]**2))
        res=minimize(nll,np.zeros(X1.shape[1]),method='L-BFGS-B',options={'maxiter':maxiter})
        if not res.success: raise RuntimeError(f'state-rate fit failed: {res.message}')
        self.params=StateRateParameters(float(res.x[0]),tuple(map(float,res.x[1:])),float(l2)); return self.params,res
    def forecast(self,*,cells,features,exposure,cutoff_time,horizon_end,region_id,magnitude_min,magnitude_max,input_snapshot_ids,code_version='epip-3.1.0'):
        if not hasattr(self,'params'): raise ValueError('fit model first')
        X=np.asarray(features,float); expv=np.asarray(exposure,float); beta=np.asarray((self.params.intercept,*self.params.coefficients))
        eta=np.clip(np.column_stack([np.ones(len(X)),X])@beta+np.log(np.maximum(expv,1e-12)),-30,30); lam=np.exp(eta)
        out=[ForecastCell(**c,magnitude_min=magnitude_min,magnitude_max=magnitude_max,probability=float(1-np.exp(-l)),expected_count=float(l),uncertainty=float(np.sqrt(l))) for c,l in zip(cells,lam)]
        fid='fcst-'+sha256_json({'model':self.model_id,'params':self.params.__dict__,'cutoff':cutoff_time,'horizon':horizon_end,'inputs':sorted(input_snapshot_ids)})[:20]
        return Forecast(forecast_id=fid,model_id=self.model_id,model_version=self.model_version,created_at=utcnow(),cutoff_time=cutoff_time,horizon_end=horizon_end,region_id=region_id,magnitude_min=magnitude_min,magnitude_max=magnitude_max,input_snapshot_ids=sorted(input_snapshot_ids),code_version=code_version,parameter_hash=sha256_json(self.params.__dict__),status='CREATED',cells=out)
