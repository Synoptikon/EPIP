from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable
import math
import numpy as np
from epip.models import Forecast, ForecastCell
from epip.core.hashing import sha256_json
from epip.core.validation import utcnow

@dataclass(frozen=True)
class EnsembleWeights:
    poisson: float = 0.5
    etas: float = 0.5
    def normalized(self):
        s=max(self.poisson,0)+max(self.etas,0)
        if s<=0: raise ValueError('ensemble weights must have positive sum')
        return EnsembleWeights(max(self.poisson,0)/s,max(self.etas,0)/s)

class ProbabilisticEnsemble:
    model_id='ensemble'
    model_version='1.1.0'
    def __init__(self, weights:EnsembleWeights|None=None): self.weights=(weights or EnsembleWeights()).normalized()
    def combine(self, poisson:Forecast, etas:Forecast, *, code_version='epip-3.2.0') -> Forecast:
        if len(poisson.cells)!=len(etas.cells): raise ValueError('forecast grids must have same size')
        w=self.weights
        cells=[]
        for a,b in zip(poisson.cells,etas.cells):
            if abs(a.latitude-b.latitude)>1e-9 or abs(a.longitude-b.longitude)>1e-9 or abs(a.depth_km-b.depth_km)>1e-9:
                raise ValueError('forecast grids are not aligned')
            p=w.poisson*a.probability+w.etas*b.probability
            lam=w.poisson*a.expected_count+w.etas*b.expected_count
            cells.append(ForecastCell(longitude=a.longitude,latitude=a.latitude,depth_km=a.depth_km,magnitude_min=a.magnitude_min,magnitude_max=a.magnitude_max,probability=float(min(1,max(0,p))),expected_count=float(max(0,lam)),uncertainty=float(math.sqrt(max(0,lam)))))
        snapshots=sorted(set(poisson.input_snapshot_ids+etas.input_snapshot_ids))
        fid='fcst-'+sha256_json({'model':self.model_id,'weights':w.__dict__,'inputs':[poisson.forecast_id,etas.forecast_id]})[:20]
        return Forecast(forecast_id=fid,model_id=self.model_id,model_version=self.model_version,created_at=utcnow(),cutoff_time=poisson.cutoff_time,horizon_end=poisson.horizon_end,region_id=poisson.region_id,magnitude_min=poisson.magnitude_min,magnitude_max=poisson.magnitude_max,input_snapshot_ids=snapshots,code_version=code_version,parameter_hash=sha256_json(w.__dict__),status='CREATED',cells=cells)

def weights_from_scores(brier_poisson:float|None,brier_etas:float|None, *, floor=0.05) -> EnsembleWeights:
    """Skill-derived weights. Lower Brier gets larger weight; requires finite scores."""
    vals=[brier_poisson,brier_etas]
    if any(v is None or not np.isfinite(v) or v<0 for v in vals): return EnsembleWeights()
    inv=np.array([1/max(float(v),1e-8) for v in vals]); inv=np.maximum(inv,0)
    inv=inv/inv.sum(); inv=np.maximum(inv,floor); inv=inv/inv.sum()
    return EnsembleWeights(float(inv[0]),float(inv[1]))
