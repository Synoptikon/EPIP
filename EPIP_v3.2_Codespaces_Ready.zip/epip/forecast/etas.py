from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
from math import exp, log, pi
import numpy as np
from scipy.optimize import minimize
from epip.models import Event, Forecast, ForecastCell
from epip.core.hashing import sha256_json
from epip.core.validation import utcnow
from epip.geometry.association import haversine_km

@dataclass(frozen=True)
class ETASParameters:
    mu: float
    K: float
    alpha: float
    c: float
    p: float
    d0_km: float
    q: float
    m0: float
    b: float = 1.0

    @property
    def branching_ratio(self) -> float:
        beta = self.b * np.log(10.0)
        if self.alpha >= beta:
            return float('inf')
        return float(self.K * beta / (beta - self.alpha))

class ETASModel:
    """Stable ETAS implementation with bounded parameters and explicit subcriticality."""
    model_id = 'etas'
    model_version = '2.1.0'

    @staticmethod
    def _temporal_kernel(dt, c, p):
        dt=np.asarray(dt,float)
        return (p-1.0)/c * (1.0+dt/c)**(-p)

    @staticmethod
    def _spatial_kernel(r, d0, q):
        r=np.asarray(r,float)
        return (q-1.0)/(pi*d0*d0) * (1.0+(r/d0)**2)**(-q)

    @staticmethod
    def _unpack(z):
        # Direct bounded physical parameters. This prevents alpha<0 and extreme q/p solutions.
        mu,K,alpha,c,p,d0,q = np.exp(z[0]), np.exp(z[1]), z[2], np.exp(z[3]), 1.0+np.exp(z[4]), np.exp(z[5]), 1.0+np.exp(z[6])
        return mu,K,alpha,c,p,d0,q

    def fit(self, events:list[Event], *, region_area_km2:float, m0:float, b:float=1.0,
            max_branching_ratio:float=0.95, maxiter:int=600, min_events:int=10):
        if len(events)<min_events:
            raise ValueError(f'ETAS fitting requires at least {min_events} events')
        events=sorted(events,key=lambda e:e.origin_time)
        t0=events[0].origin_time
        td=np.array([(e.origin_time-t0).total_seconds()/86400.0 for e in events])
        mags=np.array([e.magnitude for e in events],float)
        n=len(events); T=max(td[-1],1e-6); area=max(float(region_area_km2),1e-6)
        rmat=np.zeros((n,n))
        for i,e in enumerate(events):
            for j in range(i): rmat[i,j]=haversine_km(e.latitude,e.longitude,events[j].latitude,events[j].longitude)

        beta=b*np.log(10.0)
        def unpack(z):
            return self._unpack(z)
        def nll(z):
            mu,K,alpha,c,p,d0,q=unpack(z)
            if alpha >= beta or alpha < 0: return 1e30
            branching=K*beta/(beta-alpha)
            if branching >= max_branching_ratio: return 1e30 + (branching-max_branching_ratio)*1e20
            lam=np.full(n,mu)
            for i in range(1,n):
                dt=td[i]-td[:i]
                spatial=self._spatial_kernel(rmat[i,:i],d0,q)
                trig=K*np.exp(np.clip(alpha*(mags[:i]-m0),-50,50))*self._temporal_kernel(dt,c,p)*spatial
                lam[i]+=np.sum(trig)
            if np.any(~np.isfinite(lam)) or np.any(lam<=0): return 1e30
            ll=float(np.sum(np.log(lam)))
            comp=mu*area*T
            for i in range(n):
                dt0=max(td[-1]-td[i],0.0)
                temporal=1.0-(1.0+dt0/c)**(1.0-p)
                comp += K*np.exp(np.clip(alpha*(mags[i]-m0),-50,50))*temporal
            # Mild regularization discourages pathological scales without dominating likelihood.
            penalty=1e-5*(np.log10(d0/10.0)**2 + np.log10(c/0.01)**2)
            return comp-ll+penalty

        x0=np.array([log(max(n/(area*T),1e-8)),log(0.02),0.8,log(0.01),log(0.2),log(10.0),log(1.0)],float)
        bounds=[(log(1e-12),log(10.0)),(log(1e-8),log(1.0)),(0.0,min(2.0,beta*0.98)),(log(1e-5),log(30.0)),(log(0.01),log(2.0)),(log(0.05),log(500.0)),(log(0.01),log(4.0))]
        res=minimize(nll,x0,method='L-BFGS-B',bounds=bounds,options={'maxiter':maxiter,'ftol':1e-10})
        if not res.success: raise RuntimeError(f'ETAS fit failed: {res.message}')
        vals=unpack(res.x)
        params=ETASParameters(mu=vals[0],K=vals[1],alpha=vals[2],c=vals[3],p=vals[4],d0_km=vals[5],q=vals[6],m0=m0,b=b)
        if params.branching_ratio >= max_branching_ratio:
            raise RuntimeError('ETAS fit produced a supercritical/near-critical branching ratio')
        self.params=params
        return params,res

    def forecast_grid(self, *, events:list[Event], cutoff_time:datetime, horizon_end:datetime,
                      cells:list[dict], cell_area_km2:float, region_area_km2:float,
                      magnitude_min:float, magnitude_max:float, input_snapshot_ids:list[str],
                      code_version='epip-3.0.0') -> Forecast:
        if self.params is None: raise ValueError('fit ETAS before forecasting')
        p=self.params; horizon=max((horizon_end-cutoff_time).total_seconds()/86400.0,0.0)
        if horizon<=0: raise ValueError('horizon_end must be after cutoff_time')
        hist=[e for e in events if e.origin_time<=cutoff_time]
        mag_fraction=10**(-p.b*max(magnitude_min-p.m0,0.0))
        out=[]
        for cell in cells:
            lam=p.mu*cell_area_km2*horizon*mag_fraction
            for e in hist:
                age=max((cutoff_time-e.origin_time).total_seconds()/86400.0,0.0)
                future_age=age+horizon
                temporal=(1+age/p.c)**(1-p.p)-(1+future_age/p.c)**(1-p.p)
                r=haversine_km(cell['latitude'],cell['longitude'],e.latitude,e.longitude)
                spatial=float(self._spatial_kernel(r,p.d0_km,p.q))
                productivity=p.K*exp(float(np.clip(p.alpha*(e.magnitude-p.m0),-50,50)))
                lam += productivity*temporal*spatial*cell_area_km2*mag_fraction
            lam=max(float(lam),0.0)
            out.append(ForecastCell(**cell,magnitude_min=magnitude_min,magnitude_max=magnitude_max,
                probability=float(1-exp(-lam)),expected_count=lam,uncertainty=float(np.sqrt(lam))))
        fid='fcst-'+sha256_json({'model':self.model_id,'version':self.model_version,'params':self.params.__dict__,'cutoff':cutoff_time,'horizon':horizon_end,'snapshots':sorted(input_snapshot_ids)})[:20]
        return Forecast(forecast_id=fid,model_id=self.model_id,model_version=self.model_version,created_at=utcnow(),
            cutoff_time=cutoff_time,horizon_end=horizon_end,region_id='grid',magnitude_min=magnitude_min,magnitude_max=magnitude_max,
            input_snapshot_ids=sorted(input_snapshot_ids),code_version=code_version,parameter_hash=sha256_json(self.params.__dict__),status='CREATED',cells=out)
