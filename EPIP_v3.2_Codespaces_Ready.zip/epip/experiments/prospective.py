from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import hashlib, json, sqlite3
from pathlib import Path

@dataclass(frozen=True)
class ExperimentSpec:
    experiment_id:str
    model_id:str
    model_version:str
    region_id:str
    cutoff_time:datetime
    horizon_end:datetime
    magnitude_min:float
    magnitude_max:float
    catalog_snapshot_id:str
    code_version:str

class ProspectiveExperiment:
    """Immutable forecast contract. Once frozen, spec cannot be edited."""
    def __init__(self,path='data/epip.sqlite'):
        self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True)
        with sqlite3.connect(self.path) as c:
            c.execute('''CREATE TABLE IF NOT EXISTS prospective_experiments (experiment_id TEXT PRIMARY KEY, spec_json TEXT NOT NULL, status TEXT NOT NULL, created_at TEXT NOT NULL, frozen_at TEXT)''')
    @staticmethod
    def id_for(spec:ExperimentSpec)->str:
        p=asdict(spec); p['cutoff_time']=spec.cutoff_time.isoformat(); p['horizon_end']=spec.horizon_end.isoformat()
        return 'exp-'+hashlib.sha256(json.dumps(p,sort_keys=True).encode()).hexdigest()[:20]
    def create(self,spec:ExperimentSpec):
        eid=self.id_for(spec); payload=asdict(spec); payload['cutoff_time']=spec.cutoff_time.isoformat(); payload['horizon_end']=spec.horizon_end.isoformat(); payload['experiment_id']=eid
        with sqlite3.connect(self.path) as c: c.execute('INSERT OR IGNORE INTO prospective_experiments VALUES (?,?,?,?,?)',(eid,json.dumps(payload,sort_keys=True),'CREATED',datetime.now(timezone.utc).isoformat(),None))
        return eid
    def freeze(self,experiment_id:str):
        with sqlite3.connect(self.path) as c:
            row=c.execute('SELECT status FROM prospective_experiments WHERE experiment_id=?',(experiment_id,)).fetchone()
            if not row: raise KeyError(experiment_id)
            if row[0] != 'CREATED': raise ValueError(f'cannot freeze {row[0]}')
            c.execute('UPDATE prospective_experiments SET status="FROZEN", frozen_at=? WHERE experiment_id=?',(datetime.now(timezone.utc).isoformat(),experiment_id))
    def get(self,experiment_id):
        with sqlite3.connect(self.path) as c: return c.execute('SELECT spec_json,status,frozen_at FROM prospective_experiments WHERE experiment_id=?',(experiment_id,)).fetchone()
