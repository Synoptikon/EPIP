from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime,timedelta,timezone
import json,math
from pathlib import Path
import numpy as np
from epip.ingest.usgs import USGSComCatClient
from epip.catalog.store import CatalogStore
from epip.catalog.completeness import CompletenessEngine
from epip.forecast.poisson import PoissonBaseline
from epip.forecast.etas import ETASModel
from epip.forecast.ensemble import ProbabilisticEnsemble
from epip.evaluation.scorecard import score_model
from epip.evaluation.report import build_report,markdown
from epip.experiments.registry import ExperimentRegistry
@dataclass(frozen=True)
class Region:
 region_id:str; minlat:float; maxlat:float; minlon:float; maxlon:float; area_km2:float
class ScientificPipeline:
 def __init__(self,db='data/epip.sqlite'):self.db=Path(db);self.store=CatalogStore(self.db);self.registry=ExperimentRegistry(self.db)
 def acquire_usgs(self,start,end,region,min_magnitude=2.5):
  events,meta=USGSComCatClient().fetch(starttime=start,endtime=end,minmagnitude=min_magnitude,minlatitude=region.minlat,maxlatitude=region.maxlat,minlongitude=region.minlon,maxlongitude=region.maxlon); inserted=self.store.upsert(events); snap=self.store.create_snapshot('USGS_COMCAT',str(meta.get('generated','unknown')),{ 'starttime':start.isoformat(),'endtime':end.isoformat(),'region':region.__dict__,'minmagnitude':min_magnitude},events); return events,snap,inserted
 def build_forecasts(self,events,cutoff,horizon_days,region,magnitude_min,magnitude_max,grid_n=8,snapshot_ids=None):
  hist=[e for e in events if e.origin_time<=cutoff];cells=[{'longitude':float(lon),'latitude':float(lat),'depth_km':10.0} for lat in np.linspace(region.minlat,region.maxlat,grid_n) for lon in np.linspace(region.minlon,region.maxlon,grid_n)];cell_area=region.area_km2/len(cells);horizon=horizon_days/365.25;mc=CompletenessEngine().estimate(hist).mc;m0=float(mc if math.isfinite(mc) else magnitude_min);eligible=[e for e in hist if e.magnitude>=m0];eligible_target=[e for e in eligible if e.magnitude>=magnitude_min];duration_days=max((max((e.origin_time for e in eligible_target), default=cutoff)-min((e.origin_time for e in eligible_target), default=cutoff)).total_seconds()/86400.0, 1.0)
  rate=(len(eligible_target)/duration_days)*(horizon_days/365.25)/len(cells)
  pb=PoissonBaseline().forecast(cutoff_time=cutoff,horizon_end=cutoff+timedelta(days=horizon_days),region_id=region.region_id,cells=cells,input_snapshot_ids=snapshot_ids or [],rate_per_cell=np.full(len(cells),rate),magnitude_min=magnitude_min,magnitude_max=magnitude_max,code_version='epip-3.2.0');etas=None
  if len(eligible)>=10:
   try:
    et=ETASModel();et.fit(eligible,region_area_km2=region.area_km2,m0=m0,b=1.0,min_events=10);etas=et.forecast_grid(events=eligible,cutoff_time=cutoff,horizon_end=cutoff+timedelta(days=horizon_days),cells=cells,cell_area_km2=cell_area,region_area_km2=region.area_km2,magnitude_min=magnitude_min,magnitude_max=magnitude_max,input_snapshot_ids=snapshot_ids or [],code_version='epip-3.2.0')
   except Exception:etas=None
  ens=ProbabilisticEnsemble().combine(pb,etas,code_version='epip-3.2.0') if etas else None;return {'poisson':pb,'etas':etas,'ensemble':ens,'mc':m0,'eligible_events':len(eligible),'eligible_target':len(eligible_target)}
 def save_forecasts(self,forecasts):
  from epip.registry.prospective import ProspectiveRegistry
  r=ProspectiveRegistry(self.db)
  for f in forecasts.values():
   if hasattr(f,'forecast_id'): r.save(f); r.transition(f.forecast_id,'VALIDATED'); r.transition(f.forecast_id,'FROZEN')
 def evaluate_against_events(self,forecasts,observed):
  out={}
  for name,f in forecasts.items():
   if not hasattr(f,'cells'):continue
   cells=[x.model_dump() for x in f.cells];y=np.zeros(len(cells));counts=np.zeros(len(cells))
   for e in observed:
    if e.origin_time<=f.cutoff_time or e.origin_time>f.horizon_end:continue
    i=int(np.argmin([(c['latitude']-e.latitude)**2+(c['longitude']-e.longitude)**2 for c in cells]));y[i]=1;counts[i]+=1
   p=np.array([c.probability for c in f.cells]);lam=np.array([c.expected_count for c in f.cells]);out[name]=score_model(p,y,lam,counts)
  return out
 def write_report(self,path,experiment,score,notes=None):
  report=build_report(experiment=experiment,models=score,notes=notes);Path(path).write_text(markdown(report),encoding='utf-8');Path(str(path).replace('.md','.json')).write_text(json.dumps(report,indent=2),encoding='utf-8');return report
