from __future__ import annotations
from datetime import datetime,timezone
import hashlib,json,sqlite3
from pathlib import Path
class ExperimentRegistry:
    def __init__(self,path='data/epip.sqlite'):
        self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True)
        with sqlite3.connect(self.path) as c:c.execute('CREATE TABLE IF NOT EXISTS scientific_experiments (experiment_id TEXT PRIMARY KEY,spec_json TEXT NOT NULL,status TEXT NOT NULL,created_at TEXT NOT NULL,frozen_at TEXT)')
    def create(self,**spec):
        cfg=spec.pop('config',{}) or {}; spec['config_hash']=hashlib.sha256(json.dumps(cfg,sort_keys=True,separators=(',',':')).encode()).hexdigest(); spec['cutoff_time']=spec['cutoff_time'].isoformat() if hasattr(spec['cutoff_time'],'isoformat') else str(spec['cutoff_time']); spec['created_at']=datetime.now(timezone.utc).isoformat(); eid='exp-'+hashlib.sha256(json.dumps(spec,sort_keys=True).encode()).hexdigest()[:24]; spec['experiment_id']=eid
        with sqlite3.connect(self.path) as c:c.execute('INSERT OR IGNORE INTO scientific_experiments VALUES (?,?,?,?,?)',(eid,json.dumps(spec,sort_keys=True),'CREATED',spec['created_at'],None))
        return eid
    def freeze(self,eid):
        with sqlite3.connect(self.path) as c:
            r=c.execute('SELECT status FROM scientific_experiments WHERE experiment_id=?',(eid,)).fetchone()
            if not r:raise KeyError(eid)
            if r[0]!='CREATED':raise ValueError(f'cannot freeze experiment in {r[0]}')
            c.execute('UPDATE scientific_experiments SET status="FROZEN",frozen_at=? WHERE experiment_id=?',(datetime.now(timezone.utc).isoformat(),eid))
    def get(self,eid):
        with sqlite3.connect(self.path) as c:return c.execute('SELECT spec_json,status,frozen_at FROM scientific_experiments WHERE experiment_id=?',(eid,)).fetchone()
    def list(self):
        with sqlite3.connect(self.path) as c:return c.execute('SELECT experiment_id,status,created_at,frozen_at FROM scientific_experiments ORDER BY created_at DESC').fetchall()
