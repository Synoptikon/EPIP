from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
import numpy as np
from .metrics import brier_score, log_loss, poisson_log_likelihood

@dataclass(frozen=True)
class ProspectiveWindow:
    cutoff: datetime
    horizon_end: datetime
    region_id: str
    magnitude_min: float
    magnitude_max: float

class ProspectiveEvaluator:
    version='2.1.0'
    def evaluate_binary(self, forecast_id, probabilities, outcomes, evaluated_at):
        return {'forecast_id':forecast_id,'brier':brier_score(probabilities,outcomes),'log_loss':log_loss(probabilities,outcomes),'evaluated_at':evaluated_at.isoformat(),'evaluator_version':self.version}
    def evaluate_count(self, forecast_id, expected_counts, observed_counts, evaluated_at):
        e=np.asarray(expected_counts,float); o=np.asarray(observed_counts,float)
        return {'forecast_id':forecast_id,'poisson_log_likelihood':poisson_log_likelihood(e,o),'expected_count':float(e.sum()),'observed_count':int(o.sum()),'evaluated_at':evaluated_at.isoformat(),'evaluator_version':self.version}
    @staticmethod
    def calibration_table(probabilities,outcomes,bins=10):
        p=np.asarray(probabilities,float); y=np.asarray(outcomes,float)
        edges=np.linspace(0,1,bins+1); rows=[]
        for lo,hi in zip(edges[:-1],edges[1:]):
            mask=(p>=lo)&(p<hi if hi<1 else p<=hi)
            if mask.any(): rows.append({'bin_low':lo,'bin_high':hi,'n':int(mask.sum()),'mean_probability':float(p[mask].mean()),'event_rate':float(y[mask].mean())})
        return rows
