from __future__ import annotations
import numpy as np
from .metrics import brier_score,log_loss,poisson_log_likelihood
def calibration_table(probabilities,outcomes,bins=10):
 p=np.asarray(probabilities,float); y=np.asarray(outcomes,float); edges=np.linspace(0,1,bins+1); rows=[]
 for i in range(bins):
  mask=(p>=edges[i]) & ((p<edges[i+1]) if i<bins-1 else (p<=edges[i+1]))
  if mask.any():rows.append({'bin_low':float(edges[i]),'bin_high':float(edges[i+1]),'n':int(mask.sum()),'mean_probability':float(p[mask].mean()),'observed_rate':float(y[mask].mean())})
 return rows
def score_model(probabilities,outcomes,expected_count=None,observed_count=None):
 p=np.asarray(probabilities,float); y=np.asarray(outcomes,float); out={'brier':brier_score(p,y),'log_loss':log_loss(p,y),'n':int(p.size),'calibration':calibration_table(p,y)}
 if expected_count is not None and observed_count is not None:out['poisson_log_likelihood']=poisson_log_likelihood(expected_count,observed_count)
 return out
def paired_delta(a,b):
 if a['n']!=b['n']:raise ValueError('paired score lengths differ')
 return {'brier_delta_a_minus_b':a['brier']-b['brier'],'log_loss_delta_a_minus_b':a['log_loss']-b['log_loss']}

def paired_bootstrap_delta(a,b,metric='brier',n_boot=2000,seed=12345,alpha=.05):
    """Bootstrap CI for paired per-observation score arrays. Inputs are score contributions, not aggregate scores."""
    x=np.asarray(a,float); y=np.asarray(b,float)
    if x.shape!=y.shape or x.size<2: raise ValueError('paired arrays must have same size >=2')
    rng=np.random.default_rng(seed); idx=rng.integers(0,x.size,size=(n_boot,x.size)); d=(x[idx]-y[idx]).mean(axis=1); lo,hi=np.quantile(d,[alpha/2,1-alpha/2])
    return {'delta_mean':float((x-y).mean()),'ci_low':float(lo),'ci_high':float(hi),'n_boot':n_boot,'alpha':alpha}
