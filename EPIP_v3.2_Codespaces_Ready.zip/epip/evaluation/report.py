from datetime import datetime,timezone
def build_report(experiment,models,notes=None):
 ranked=sorted(models,key=lambda k:models[k].get('brier',float('inf')));return {'generated_at':datetime.now(timezone.utc).isoformat(),'experiment':experiment,'models':models,'ranking_by_brier':ranked,'notes':notes or []}
def markdown(report):
 lines=['# EPIP Prospective Scientific Report','',f"Generated: {report['generated_at']}",'','## Experiment','']+[f"- **{k}**: {v}" for k,v in report['experiment'].items()]+['','## Model scorecard','','| Model | N | Brier | LogLoss |','|---|---:|---:|---:|']
 lines += [f"| {n} | {s.get('n','-')} | {s.get('brier','-')} | {s.get('log_loss','-')} |" for n,s in report['models'].items()]; lines += ['','## Ranking by Brier','', ' → '.join(report['ranking_by_brier'])]
 if report['notes']:lines += ['','## Notes']+[f'- {x}' for x in report['notes']]
 return '\n'.join(lines)+'\n'
