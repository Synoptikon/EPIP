import numpy as np

def brier_score(probabilities, outcomes):
    p=np.asarray(probabilities,float); y=np.asarray(outcomes,float)
    if p.shape != y.shape: raise ValueError('shape mismatch')
    return float(np.mean((p-y)**2))

def log_loss(probabilities, outcomes, eps=1e-15):
    p=np.clip(np.asarray(probabilities,float), eps, 1-eps)
    y=np.asarray(outcomes,float)
    if p.shape != y.shape: raise ValueError('shape mismatch')
    return float(-np.mean(y*np.log(p)+(1-y)*np.log(1-p)))

def poisson_log_likelihood(expected_count, observed_count):
    """Per-cell Poisson log likelihood without requiring scipy."""
    from math import lgamma, log
    lam=np.asarray(expected_count,float); k=np.asarray(observed_count,float)
    if np.any(lam < 0) or lam.shape != k.shape: raise ValueError('invalid inputs')
    safe=np.maximum(lam, 1e-15)
    return float(np.sum(k*np.log(safe)-safe-np.vectorize(lgamma)(k+1)))
