from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import json, hashlib

@dataclass(frozen=True)
class Snapshot:
    snapshot_id: str
    source: str
    source_version: str
    retrieved_at: datetime
    query: dict
    coverage_start: datetime | None
    coverage_end: datetime | None
    record_count: int
    sha256: str
    schema_version: str='2.0.0'
    quality_status: str='UNKNOWN'

    def canonical(self):
        return json.dumps(asdict(self), sort_keys=True, default=str, separators=(',',':'))

def snapshot_hash(payload):
    return hashlib.sha256(json.dumps(payload,sort_keys=True,default=str,separators=(',',':')).encode()).hexdigest()
