import hashlib, json

def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def sha256_json(obj) -> str:
    raw = json.dumps(obj, sort_keys=True, separators=(',', ':'), default=str).encode()
    return sha256_bytes(raw)
