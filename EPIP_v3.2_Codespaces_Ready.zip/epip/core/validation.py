from datetime import datetime, timezone
import math

def utcnow():
    return datetime.now(timezone.utc)

def require_probability(p: float) -> None:
    if not math.isfinite(p) or not 0 <= p <= 1:
        raise ValueError('probability must be finite and in [0,1]')

def require_temporal_cutoff(event_time: datetime, cutoff: datetime) -> None:
    if event_time > cutoff:
        raise ValueError('temporal leakage: event occurs after forecast cutoff')
