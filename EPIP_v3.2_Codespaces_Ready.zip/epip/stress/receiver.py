from __future__ import annotations
from dataclasses import dataclass
from math import radians, sin, cos
import numpy as np

@dataclass(frozen=True)
class ReceiverFaultPlane:
    receiver_id: str
    east_m: float
    north_m: float
    depth_m: float
    strike_deg: float
    dip_deg: float
    rake_deg: float
    friction: float = 0.6

    def vectors(self):
        st, dp, rk = map(radians, (self.strike_deg, self.dip_deg, self.rake_deg))
        strike = np.array([cos(st), sin(st), 0.0])
        normal_h = np.array([-sin(st), cos(st), 0.0])
        down_dip = np.array([normal_h[0]*cos(dp), normal_h[1]*cos(dp), -sin(dp)])
        normal = np.cross(strike, down_dip)
        normal = normal / np.linalg.norm(normal)
        rake_dir = cos(rk)*strike + sin(rk)*down_dip
        rake_dir = rake_dir / np.linalg.norm(rake_dir)
        return normal, rake_dir
