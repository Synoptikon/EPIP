from dataclasses import dataclass

@dataclass(frozen=True)
class FiniteFaultRupture:
    rupture_id: str
    geometry_version: str
    length_km: float
    width_km: float
    depth_km: float
    strike_deg: float
    dip_deg: float
    rake_deg: float
    slip_m: float
    shear_modulus_pa: float

@dataclass(frozen=True)
class ReceiverFault:
    receiver_id: str
    strike_deg: float
    dip_deg: float
    rake_deg: float
    depth_km: float

@dataclass(frozen=True)
class StressResult:
    rupture_id: str
    receiver_id: str
    delta_cfs_pa: float
    method: str
    uncertainty_pa: float | None
    validated: bool

class StressEngineContract:
    """Physics boundary. No proxy may be exposed as physical ΔCFS."""
    method='FINITE_FAULT_ELASTIC'
    def compute(self, rupture: FiniteFaultRupture, receiver: ReceiverFault) -> StressResult:
        raise NotImplementedError('Attach a validated finite-fault elastic/Okada solver before producing physical ΔCFS.')
