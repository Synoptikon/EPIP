from __future__ import annotations
import numpy as np
from dataclasses import dataclass
from .receiver import ReceiverFaultPlane

@dataclass(frozen=True)
class CFSResult:
    receiver_id: str
    delta_cfs_pa: float
    shear_change_pa: float
    normal_stress_change_pa: float
    friction: float
    convention: str = 'positive_delta_cfs_promotes_failure'


def stress_to_cfs(stress_tensor_pa, receiver: ReceiverFaultPlane) -> CFSResult:
    sigma = np.asarray(stress_tensor_pa, dtype=float)
    if sigma.shape != (3,3) or not np.all(np.isfinite(sigma)):
        raise ValueError('stress tensor must be a finite 3x3 matrix')
    sigma = 0.5 * (sigma + sigma.T)
    n, rake = receiver.vectors()
    traction = sigma @ n
    normal = float(n @ traction)
    shear_vec = traction - normal*n
    shear = float(rake @ shear_vec)
    # Compression-positive stress convention: increasing compression closes fault.
    # Thus Coulomb failure stress uses -friction*dSigma_n.
    dcfs = shear - receiver.friction * normal
    return CFSResult(receiver.receiver_id, dcfs, shear, normal, receiver.friction)
