# EPIP v2.5 — Finite-Fault Physical Stress Engine

EPIP v2.5 adds a physical-stress boundary and an optional elastic half-space backend.

## Design rule

A proxy, Coulomb-style heuristic, or statistical score is **not** exposed as physical ΔCFS.

The physical path is:

`finite rupture -> elastic dislocation elements -> strain -> stress tensor -> receiver traction -> shear/normal stress -> ΔCFS`

The optional `cutde` backend provides triangular dislocation elements in an elastic half-space. EPIP triangulates the rectangular rupture into two triangles and computes strain at the receiver point. The stress tensor is derived from isotropic linear elasticity.

## Coordinate convention

Local Cartesian coordinates are East, North, Up. Depth is represented as negative Up. Strike is clockwise from North. Rake follows the strike/dip basis. Receiver Coulomb stress uses:

`ΔCFS = Δτ_rake - μ Δσ_n`

under a compression-positive normal-stress convention.

## Scientific limitations

This is a finite-fault elastic model, not a complete earthquake stress forecast. It requires defensible source geometry, slip distribution, elastic parameters, receiver geometry, and observation locations. Homogeneous isotropic half-space assumptions are explicit. Heterogeneous crust, layered media, topography, dynamic stress, poroelasticity and viscoelastic relaxation are not silently included.

Physical backend activation should be followed by benchmark tests against an independently trusted implementation before use in EPIP forecasts.
