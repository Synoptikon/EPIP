from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from .finite_fault import RectangularRupture
from .receiver import ReceiverFaultPlane
from .backend import ElasticBackend
from .cfs import stress_to_cfs, CFSResult

@dataclass(frozen=True)
class PhysicalStressResult:
    rupture_id: str
    receiver_id: str
    delta_cfs_pa: float
    shear_change_pa: float
    normal_stress_change_pa: float
    backend: str
    validated: bool
    uncertainty_pa: float | None

class FiniteFaultStressEngine:
    def __init__(self, backend: ElasticBackend):
        if not getattr(backend, 'validated', False):
            raise ValueError('Only a validated elastic backend can be used for physical ΔCFS')
        self.backend = backend

    def compute(self, rupture: RectangularRupture, receiver: ReceiverFaultPlane) -> PhysicalStressResult:
        obs = (receiver.east_m, receiver.north_m, -receiver.depth_m)
        tensor = self.backend.stress_tensor(rupture, obs)
        result: CFSResult = stress_to_cfs(tensor, receiver)
        return PhysicalStressResult(
            rupture.rupture_id, receiver.receiver_id, result.delta_cfs_pa,
            result.shear_change_pa, result.normal_stress_change_pa,
            self.backend.name, bool(self.backend.validated), None
        )
