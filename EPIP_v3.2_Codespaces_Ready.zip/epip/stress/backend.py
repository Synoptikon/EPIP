from __future__ import annotations
from dataclasses import dataclass
from typing import Protocol
import numpy as np

from .finite_fault import RectangularRupture, rectangle_triangles, slip_vector_local

class ElasticBackend(Protocol):
    name: str
    validated: bool
    def stress_tensor(self, rupture: RectangularRupture, observation_xyz_m) -> np.ndarray: ...

@dataclass
class CutdeHalfspaceBackend:
    """Optional physical backend using cutde triangular dislocations.

    cutde implements elastic half-space dislocation elements. EPIP triangulates
    the rectangular rupture and computes strain, then converts strain to stress.
    """
    name: str = 'CUTDE_HALFSPACE_TDE'
    validated: bool = True

    def stress_tensor(self, rupture: RectangularRupture, observation_xyz_m) -> np.ndarray:
        try:
            from cutde import halfspace
        except ImportError as exc:
            raise RuntimeError('Install optional dependency cutde to enable physical stress calculations') from exc
        obs = np.asarray(observation_xyz_m, dtype=float).reshape(1,3)
        tris = np.asarray(rectangle_triangles(rupture), dtype=float)
        sv = np.asarray(slip_vector_local(rupture), dtype=float)
        slips = np.vstack([sv, sv])
        # cutde uses the source and observation coordinates in the same Cartesian frame.
        strain = halfspace.strain(obs, tris, slips, rupture.medium.poisson_ratio)[0]
        eps = np.asarray(strain, dtype=float).reshape(3,3)
        eps = 0.5*(eps+eps.T)
        mu = rupture.medium.shear_modulus_pa
        lam = rupture.medium.lame_lambda_pa
        return lam*np.trace(eps)*np.eye(3) + 2*mu*eps
