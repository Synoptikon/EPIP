from __future__ import annotations
from dataclasses import dataclass, asdict
from math import radians, sin, cos, sqrt
from typing import Any

@dataclass(frozen=True)
class ElasticMedium:
    shear_modulus_pa: float = 30e9
    poisson_ratio: float = 0.25

    @property
    def lame_lambda_pa(self) -> float:
        mu = self.shear_modulus_pa
        nu = self.poisson_ratio
        return 2.0 * mu * nu / (1.0 - 2.0 * nu)

@dataclass(frozen=True)
class RectangularRupture:
    rupture_id: str
    geometry_version: str
    center_east_m: float
    center_north_m: float
    top_depth_m: float
    length_m: float
    width_m: float
    strike_deg: float
    dip_deg: float
    rake_deg: float
    slip_m: float
    medium: ElasticMedium
    source_event_id: str | None = None
    source_provenance: dict[str, Any] | None = None

    @property
    def moment_nm(self) -> float:
        return self.medium.shear_modulus_pa * self.length_m * self.width_m * self.slip_m

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d['moment_nm'] = self.moment_nm
        return d

def moment_from_mw(mw: float) -> float:
    if not 0 < mw < 10:
        raise ValueError('Mw must be between 0 and 10')
    return 10 ** (1.5 * mw + 9.1)

def slip_from_mw(mw: float, length_m: float, width_m: float, shear_modulus_pa: float) -> float:
    if length_m <= 0 or width_m <= 0 or shear_modulus_pa <= 0:
        raise ValueError('rupture dimensions and shear modulus must be positive')
    return moment_from_mw(mw) / (shear_modulus_pa * length_m * width_m)

def rectangle_triangles(rupture: RectangularRupture):
    """Return two triangles in a local ENU Cartesian frame.

    z is positive upward; fault top is at -top_depth_m. The rectangle is
    centered horizontally and extends down-dip from its top edge.
    """
    st, dp = radians(rupture.strike_deg), radians(rupture.dip_deg)
    along = (cos(st), sin(st), 0.0)
    # right-hand horizontal normal to strike
    normal_h = (-sin(st), cos(st), 0.0)
    down_dip = (normal_h[0] * cos(dp), normal_h[1] * cos(dp), -sin(dp))
    half_l = rupture.length_m / 2.0
    # Center is supplied at the rectangle center.
    half_w = rupture.width_m / 2.0
    c = (rupture.center_east_m, rupture.center_north_m, -rupture.top_depth_m - half_w * sin(dp))
    dip_horizontal = half_w * cos(dp)
    # Coordinates from center to corners.
    def add(a,b): return tuple(a[i]+b[i] for i in range(3))
    def scale(v,s): return tuple(x*s for x in v)
    top = add(c, scale(down_dip, -half_w))
    bot = add(c, scale(down_dip, half_w))
    a = add(top, scale(along, -half_l)); b = add(top, scale(along, half_l))
    c1 = add(bot, scale(along, -half_l)); d = add(bot, scale(along, half_l))
    return [
        [a,b,d],
        [a,d,c1],
    ]

def slip_vector_local(rupture: RectangularRupture):
    st, rk = radians(rupture.strike_deg), radians(rupture.rake_deg)
    strike = (cos(st), sin(st), 0.0)
    normal_h = (-sin(st), cos(st), 0.0)
    dip = radians(rupture.dip_deg)
    down_dip = (normal_h[0]*cos(dip), normal_h[1]*cos(dip), -sin(dip))
    v = tuple((cos(rk)*strike[i] + sin(rk)*down_dip[i]) * rupture.slip_m for i in range(3))
    return v
