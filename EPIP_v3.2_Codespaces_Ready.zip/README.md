# EPIP v3.2 — Final Release Candidate

Earthquake Probabilistic Intelligence Platform. Probabilistic forecasting and prospective scientific evaluation; **not deterministic earthquake prediction**.

## Scientific pipeline

REAL DATA → MASTER CATALOG → COMPLETENESS → TECTONIC/GEODETIC/STRESS STATE → FROZEN FORECAST → 24h/7d/30d/90d → OBSERVATION → PROSPECTIVE EVALUATION → POISSON vs ETAS vs STATE CHALLENGERS vs ENSEMBLE.

## Install

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -U pip
pip install -r requirements.txt
pytest
```

Optional physical stress backend:

```bash
pip install -e '.[physical]'
```

## Live USGS / ComCat

USGS FDSN Event Web Service supports GeoJSON, geographic/time/magnitude filters and limits a query to 20,000 records; EPIP therefore paginates at that boundary and records the request metadata. urlUSGS FDSN Event Web Service documentationhttps://earthquake.usgs.gov/fdsnws/event/1/wsdl

```bash
python scripts/run_live_scientific_pipeline.py   --region mexico --days 365 --forecast-days 30   --min-mag 3.0 --magnitude 4.5
```

Network failures are fatal. EPIP never silently substitutes synthetic data for a real experiment.

## API

```bash
uvicorn epip.api.main:app --host 0.0.0.0 --port 8000
```

Core endpoints:
`/health`, `/catalog/latest`, `/catalog/stats`, `/completeness`, `/snapshots`, `/models`, `/forecast/latest`, `/evaluation/latest`, `/experiments`, `/geometry/status`, `/geodesy/status`, `/stress/finite-fault`, `/state/fuse`.

## Scientific safeguards

- immutable source snapshots and SHA-256 provenance;
- cutoff/freeze registry;
- temporal leakage prevention in prospective backtests;
- constrained/subcritical ETAS;
- no synthetic fallback in live mode;
- explicit missing-state handling;
- physical ΔCFS gated behind the physical solver;
- ML remains challenger-only until prospective evidence demonstrates improvement.

## Status

This release is **software-ready / experiment-ready**. Scientific superiority over the baselines must be established prospectively on real data; passing software tests is not evidence of predictive skill.
